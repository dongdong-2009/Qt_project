#include "uiclock.h"

UiClock::UiClock(QWidget* parent, Qt::WindowFlags f)
    :QWidget(parent,f)
{

}
