#include "uitext.h"

UiText::UiText(QWidget* parent, Qt::WindowFlags f)
    :QWidget(parent,f)
{

}
