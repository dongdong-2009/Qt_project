<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>Area1</name>
    <message>
        <source>亮度&amp;音量</source>
        <translation type="vanished">Screen settings</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="45"/>
        <location filename="Area1.qml" line="359"/>
        <source>屏幕设定</source>
        <translation>Screen settings</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="56"/>
        <location filename="Area1.qml" line="360"/>
        <source>亮度</source>
        <translation>Brightness</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="61"/>
        <location filename="Area1.qml" line="361"/>
        <source>音量</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="169"/>
        <location filename="Area1.qml" line="362"/>
        <source>音频</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="180"/>
        <location filename="Area1.qml" line="363"/>
        <source>开</source>
        <translation>on</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="200"/>
        <location filename="Area1.qml" line="364"/>
        <source>关</source>
        <translation>off</translation>
    </message>
    <message>
        <source>滚动文字</source>
        <translation type="vanished">Scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="219"/>
        <location filename="Area1.qml" line="366"/>
        <source>设置滚动文字</source>
        <translation>Set scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="248"/>
        <location filename="Area1.qml" line="376"/>
        <source>隐藏滚动文字</source>
        <translation>Hide scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="291"/>
        <location filename="Area1.qml" line="367"/>
        <source>设置标题</source>
        <translation>Set title</translation>
    </message>
    <message>
        <source>显示滚动文字</source>
        <translation type="vanished">Show scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="232"/>
        <location filename="Area1.qml" line="386"/>
        <source>请输入字幕文字</source>
        <translation>Please enter text here.At least 2 characters.</translation>
    </message>
    <message>
        <source>标题</source>
        <translation type="vanished">Title</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="322"/>
        <location filename="Area1.qml" line="385"/>
        <source>隐藏标题</source>
        <translation>Hide title</translation>
    </message>
    <message>
        <source>显示标题</source>
        <translation type="vanished">Show title</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="304"/>
        <location filename="Area1.qml" line="388"/>
        <location filename="Area1.qml" line="403"/>
        <source>请输入标题文字</source>
        <translation>Please enter text here. 2 to 16 characters.</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="399"/>
        <source>请输入滚动字幕文字</source>
        <translation>Please enter text here. Mini 2 characters.</translation>
    </message>
</context>
<context>
    <name>Area2</name>
    <message>
        <source>显示时间和日期</source>
        <translation type="vanished">Show time and date</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="45"/>
        <location filename="Area2.qml" line="350"/>
        <source>时间格式</source>
        <translation>Time format</translation>
    </message>
    <message>
        <source>音频</source>
        <oldsource>音频关</oldsource>
        <translation type="vanished">Audio</translation>
    </message>
    <message>
        <source>音频开</source>
        <translation type="vanished">Audio On</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="351"/>
        <source>12上午下午  </source>
        <translation>12 AM/PM</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="86"/>
        <location filename="Area2.qml" line="352"/>
        <source>24小时</source>
        <translation>24 hours</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="99"/>
        <location filename="Area2.qml" line="356"/>
        <source>隐藏时间和日期</source>
        <translation>Hide time and date</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="50"/>
        <location filename="Area2.qml" line="353"/>
        <source>日期格式</source>
        <translation>Date format</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="33"/>
        <location filename="Area2.qml" line="349"/>
        <source>时间和日期</source>
        <translation>Time and date</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="60"/>
        <source>12上午下午</source>
        <translation>12AM/PM</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="71"/>
        <location filename="Area2.qml" line="354"/>
        <source>yyyy:MM:dd</source>
        <oldsource>yyyy:mm:dd</oldsource>
        <translation>yyyy:MM:dd</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="90"/>
        <location filename="Area2.qml" line="355"/>
        <source>dd:MM:yyyy</source>
        <oldsource>dd:mm:yyyy</oldsource>
        <translation>dd:MM:yyyy</translation>
    </message>
    <message>
        <source>开</source>
        <translation type="vanished">on</translation>
    </message>
    <message>
        <source>关</source>
        <translation type="vanished">off</translation>
    </message>
    <message>
        <source>mm:dd:yyyy</source>
        <translation type="vanished">dd:mm:yyyy</translation>
    </message>
    <message>
        <source>屏保</source>
        <translation type="vanished">Screensaver settings</translation>
    </message>
    <message>
        <source>一阶段周期(S)</source>
        <translation type="vanished">One stage cycle(S)</translation>
    </message>
    <message>
        <source>亮度</source>
        <translation type="vanished">Brightness</translation>
    </message>
    <message>
        <source>二阶段周期(S)</source>
        <translation type="vanished">Two stage cycle(S)</translation>
    </message>
</context>
<context>
    <name>Area3</name>
    <message>
        <location filename="Area3.qml" line="26"/>
        <location filename="Area3.qml" line="574"/>
        <source>多媒体更新</source>
        <translation>Screen lay-out</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="47"/>
        <location filename="Area3.qml" line="575"/>
        <source>正常显示</source>
        <translation>With elevator information</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="59"/>
        <location filename="Area3.qml" line="576"/>
        <source>全屏显示</source>
        <translation>Fullscreen media</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="89"/>
        <location filename="Area3.qml" line="589"/>
        <source>添加多媒体</source>
        <translation>Add media content</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="102"/>
        <location filename="Area3.qml" line="577"/>
        <source>视频</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="125"/>
        <location filename="Area3.qml" line="578"/>
        <source>音频</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="147"/>
        <location filename="Area3.qml" line="579"/>
        <source>图片</source>
        <translation>Picture</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="197"/>
        <location filename="Area3.qml" line="580"/>
        <source>选择视频</source>
        <translation>Select video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="248"/>
        <location filename="Area3.qml" line="582"/>
        <source>选择音频</source>
        <translation>Select Audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="282"/>
        <location filename="Area3.qml" line="581"/>
        <source>选择图片</source>
        <translation>Select Picture</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="324"/>
        <location filename="Area3.qml" line="588"/>
        <source>间隔</source>
        <translation>interval</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="389"/>
        <location filename="Area3.qml" line="583"/>
        <source>添加</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="395"/>
        <location filename="Area3.qml" line="584"/>
        <source>删除</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="400"/>
        <location filename="Area3.qml" line="585"/>
        <source>清空</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="414"/>
        <location filename="Area3.qml" line="590"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="493"/>
        <location filename="Area3.qml" line="586"/>
        <source>请选择一个视频文件</source>
        <translation>Please select pictures</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="504"/>
        <source>请选择一个音频文件</source>
        <translation>Please select audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="530"/>
        <location filename="Area3.qml" line="587"/>
        <source>请选取图片</source>
        <translation>Please select pictures</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="553"/>
        <source>请选择一个视频</source>
        <translation>Please select a video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="559"/>
        <source>请选择一个音频</source>
        <translation>Please select audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="565"/>
        <source>请选择图片</source>
        <translation>Please select pictures</translation>
    </message>
</context>
<context>
    <name>Area4</name>
    <message>
        <location filename="Area4.qml" line="21"/>
        <location filename="Area4.qml" line="202"/>
        <source>语言切换</source>
        <translation>Language selection</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="38"/>
        <source>中文</source>
        <translation>Chinese</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="61"/>
        <source>繁體</source>
        <oldsource>繁体</oldsource>
        <translation type="unfinished">Traditional</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="85"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area4.qml" line="106"/>
        <source>русский язык</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>英语</source>
        <translation type="vanished">English</translation>
    </message>
    <message>
        <source>俄语</source>
        <translation type="vanished">Russian</translation>
    </message>
</context>
<context>
    <name>Area5</name>
    <message>
        <location filename="Area5.qml" line="15"/>
        <location filename="Area5.qml" line="277"/>
        <source>升级盘制作</source>
        <translation>Upgrade content on USB</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="92"/>
        <location filename="Area5.qml" line="278"/>
        <source>重置为默认配置</source>
        <translation>Reset default configuration</translation>
    </message>
    <message>
        <source>界面预览</source>
        <translation type="vanished">Screen Preview</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="33"/>
        <location filename="Area5.qml" line="279"/>
        <source>制作升级盘</source>
        <translation>Select device:</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="53"/>
        <location filename="Area5.qml" line="280"/>
        <source>制作</source>
        <translation>UPLOAD</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="vanished">Formatting U disk.....</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="281"/>
        <source>拷贝文件...</source>
        <translation>Copy file...</translation>
    </message>
    <message>
        <source>正在生成配置参数</source>
        <translation type="vanished">Generating configuration parameters...</translation>
    </message>
    <message>
        <source>升级盘制作成功</source>
        <translation type="vanished">Upgrade disk production success</translation>
    </message>
</context>
<context>
    <name>Horizontal_ImageOrVideo</name>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="39"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="142"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="66"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="143"/>
        <source>横屏显示</source>
        <translation>Horizontal Show</translation>
    </message>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="87"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="144"/>
        <source>竖屏显示</source>
        <translation>Vertical Show</translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="39"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="66"/>
        <source>кросс экраном</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="88"/>
        <source>вертикальный экран</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MakeDisk</name>
    <message>
        <source>重置为默认配置</source>
        <translation type="obsolete">Reset default configuration</translation>
    </message>
    <message>
        <source>制作升级盘</source>
        <translation type="obsolete">Make upgrade disk</translation>
    </message>
    <message>
        <source>制作</source>
        <translation type="obsolete">Making</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="obsolete">Formatting U disk.....</translation>
    </message>
    <message>
        <source>拷贝文件...</source>
        <translation type="obsolete">Copy file...</translation>
    </message>
    <message>
        <source>正在生成配置参数</source>
        <translation type="obsolete">Generating configuration parameters...</translation>
    </message>
    <message>
        <source>升级盘制作成功</source>
        <translation type="obsolete">Upgrade disk production success</translation>
    </message>
</context>
<context>
    <name>ModifyCheckBox</name>
    <message>
        <source>重置为默认配置</source>
        <translation type="obsolete">Reset default configuration</translation>
    </message>
</context>
<context>
    <name>MultiMedia</name>
    <message>
        <source>视频</source>
        <translation type="obsolete">Video</translation>
    </message>
    <message>
        <source>图片</source>
        <translation type="obsolete">Picture</translation>
    </message>
    <message>
        <source>正常显示</source>
        <translation type="obsolete">Normal display</translation>
    </message>
    <message>
        <source>全屏显示</source>
        <translation type="obsolete">Fullscreen display</translation>
    </message>
    <message>
        <source>选择视频</source>
        <translation type="obsolete">Select video</translation>
    </message>
    <message>
        <source>选择图片</source>
        <translation type="obsolete">Select Picture</translation>
    </message>
    <message>
        <source>添加</source>
        <translation type="obsolete">Add</translation>
    </message>
    <message>
        <source>删除</source>
        <translation type="obsolete">Delete</translation>
    </message>
    <message>
        <source>清空</source>
        <translation type="obsolete">Clear</translation>
    </message>
    <message>
        <source>请选择一个视频文件</source>
        <translation type="obsolete">Please select pictures</translation>
    </message>
    <message>
        <source>请选取图片</source>
        <translation type="obsolete">Please select pictures</translation>
    </message>
</context>
<context>
    <name>Parameter</name>
    <message>
        <source>亮度&amp;音量</source>
        <translation type="obsolete">Brightness &amp; volume</translation>
    </message>
    <message>
        <source>滚动文字</source>
        <translation type="obsolete">Scrolling text</translation>
    </message>
    <message>
        <source>标题</source>
        <translation type="obsolete">Title</translation>
    </message>
    <message>
        <source>屏保</source>
        <translation type="obsolete">Screensaver</translation>
    </message>
    <message>
        <source>亮度</source>
        <translation type="obsolete">Brightness</translation>
    </message>
    <message>
        <source>音量</source>
        <translation type="obsolete">Volume</translation>
    </message>
    <message>
        <source>请输入字幕文字</source>
        <translation type="obsolete">Please enter a caption text</translation>
    </message>
    <message>
        <source>时间格式</source>
        <translation type="obsolete">Time format</translation>
    </message>
    <message>
        <source>日期格式</source>
        <translation type="obsolete">Date format</translation>
    </message>
    <message>
        <source>显示标题</source>
        <translation type="obsolete">Show title</translation>
    </message>
    <message>
        <source>隐藏标题</source>
        <translation type="obsolete">Hide title</translation>
    </message>
    <message>
        <source>请输入标题文字</source>
        <translation type="obsolete">Please enter a title text</translation>
    </message>
</context>
<context>
    <name>RussianArea1</name>
    <message>
        <location filename="russian/RussianArea1.qml" line="54"/>
        <source>Яркость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="60"/>
        <source>Громкость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="219"/>
        <source>переходящий текст настройки</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="247"/>
        <source>Скрытие прокрутки текста</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="230"/>
        <source>Введите субтитра</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="289"/>
        <source>установить заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="318"/>
        <source>Скрытие заголовка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="301"/>
        <location filename="russian/RussianArea1.qml" line="361"/>
        <source>Введите заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="42"/>
        <source>экран настройки</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="168"/>
        <source>аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="179"/>
        <location filename="russian/RussianArea1.qml" line="199"/>
        <source>аудио гуань</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="356"/>
        <source>Введите прокрутку субтитра</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea2</name>
    <message>
        <location filename="russian/RussianArea2.qml" line="102"/>
        <source>Скрыть времни и даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="33"/>
        <source>время и дата</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="45"/>
        <source>Формат времени</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="51"/>
        <source>Формат даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="62"/>
        <source>12 Часов</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="73"/>
        <source>yyyy:MM:dd</source>
        <oldsource>yyyy:mm:dd</oldsource>
        <translation type="unfinished">yyyy:mm:dd</translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="88"/>
        <source>24 Часов</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="92"/>
        <source>dd:MM:yyyy</source>
        <oldsource>dd:mm:yyyy</oldsource>
        <translation type="unfinished">dd:mm:yyyy</translation>
    </message>
    <message>
        <source>mm:dd:yyyy</source>
        <translation type="obsolete">mm:dd:yyyy</translation>
    </message>
</context>
<context>
    <name>RussianArea3</name>
    <message>
        <location filename="russian/RussianArea3.qml" line="26"/>
        <source>Обновление мультимедиа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="48"/>
        <source>Нормальная индикация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="62"/>
        <source>Полноэкранная индикация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="85"/>
        <source>Добавить мультимедиа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="99"/>
        <source>Видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="122"/>
        <source>аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="145"/>
        <source>Картина</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="196"/>
        <source>Выбор видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="247"/>
        <location filename="russian/RussianArea3.qml" line="513"/>
        <location filename="russian/RussianArea3.qml" line="564"/>
        <source>выбрать аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="282"/>
        <source>Выбор картины</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="324"/>
        <source>интервал</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="396"/>
        <source>Добавить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="402"/>
        <source>Удалить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="408"/>
        <source>Очистить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="422"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="501"/>
        <location filename="russian/RussianArea3.qml" line="557"/>
        <source>Выберите видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="540"/>
        <location filename="russian/RussianArea3.qml" line="570"/>
        <source>Выберите картину</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="579"/>
        <source>多媒体更新</source>
        <translation type="unfinished">Multimedia update</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="580"/>
        <source>正常显示</source>
        <translation type="unfinished">Normal display</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="581"/>
        <source>全屏显示</source>
        <translation type="unfinished">Fullscreen display</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="582"/>
        <source>视频</source>
        <translation type="unfinished">Video</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="583"/>
        <source>音频</source>
        <translation type="unfinished">Audio</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="584"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="585"/>
        <source>选择视频</source>
        <translation type="unfinished">Select video</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="586"/>
        <source>选择图片</source>
        <translation type="unfinished">Select Picture</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="587"/>
        <source>选择音频</source>
        <translation type="unfinished">Select Audio</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="588"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="589"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="590"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="591"/>
        <source>请选择一个视频文件</source>
        <translation type="unfinished">Please select pictures</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="592"/>
        <source>请选取图片</source>
        <translation type="unfinished">Please select pictures</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="593"/>
        <source>间隔</source>
        <translation type="unfinished">interval</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="594"/>
        <source>添加多媒体</source>
        <translation type="unfinished">Add media content</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="595"/>
        <source>界面预览</source>
        <translation type="unfinished">Screen Preview</translation>
    </message>
</context>
<context>
    <name>RussianArea4</name>
    <message>
        <location filename="russian/RussianArea4.qml" line="22"/>
        <source>Переключатель языка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="39"/>
        <source>中文</source>
        <translation type="unfinished">Chinese</translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="61"/>
        <source>繁體</source>
        <translation type="unfinished">Traditional</translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="84"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="105"/>
        <source>Русский язык</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea5</name>
    <message>
        <location filename="russian/RussianArea5.qml" line="16"/>
        <source>Поделка обновления диска </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="95"/>
        <source>Вновь установления настройки по умолчанию</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="38"/>
        <source>Поделка обновления диска</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="58"/>
        <source>Поделка</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianMain</name>
    <message>
        <location filename="russian/RussianMain.qml" line="34"/>
        <source>MediaScreen Content management</source>
        <oldsource>MediaScreenHelper</oldsource>
        <translation type="unfinished">MediaScreenHelper</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="obsolete">  V1.7.0</translation>
    </message>
    <message>
        <source>  V1.2.0</source>
        <translation type="obsolete">  V1.2.0</translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="34"/>
        <source>  V2.0.0</source>
        <translation type="unfinished">  V2.0.0</translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="48"/>
        <source>Настройка параметров</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="179"/>
        <source>Включите этот параметр переключателя, на экране будет восстановлена настройка параметров по умолчанию. Мультимедиа, прокрутка субтитров, заголовок, времени и даты, параметры конфигурации системы буду
т восстановлены по умолчанию.</source>
        <oldsource>Включите этот параметр переключателя, на экране будет восстановлена настройка параметров по умолчанию. Мультимедиа, прокрутка субтитров, заголовок, времени и даты, параметры конфигурации системы буду
т восстановлены по умолчанию.</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="192"/>
        <location filename="russian/RussianMain.qml" line="236"/>
        <location filename="russian/RussianMain.qml" line="388"/>
        <source>Уточнение</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="200"/>
        <location filename="russian/RussianMain.qml" line="398"/>
        <source>Отмена</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="294"/>
        <source>Нажмите, чтобы закончить поделку</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="316"/>
        <source>Копирование файла...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="376"/>
        <source>Нажмите, чтобы подтвердить.Размещение страницы будет перезагружен.Необходимо перезагрузить USB!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="425"/>
        <source>Создание параметров конфигурации</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="428"/>
        <source>Успех в поделке обновлении диска</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="444"/>
        <source>проверить диска...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="455"/>
        <source>拷贝文件...</source>
        <translation type="unfinished">Copy file...</translation>
    </message>
</context>
<context>
    <name>Vertical_ImageOrVideo</name>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="38"/>
        <location filename="Vertical_ImageOrVideo.qml" line="131"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="63"/>
        <location filename="Vertical_ImageOrVideo.qml" line="132"/>
        <source>横屏显示</source>
        <translation>Horizontal Show</translation>
    </message>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="91"/>
        <location filename="Vertical_ImageOrVideo.qml" line="133"/>
        <source>竖屏显示</source>
        <translation>Vertical Show</translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="38"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="62"/>
        <source>кросс экраном</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="89"/>
        <source>вертикальный экран</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="34"/>
        <source>MediaScreen Content management</source>
        <oldsource>MediaScreenHelper</oldsource>
        <translation>MediaScreenHelper</translation>
    </message>
    <message>
        <source>  V1.6.0</source>
        <translation type="vanished">  V1.6.0</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="vanished">  V1.7.0</translation>
    </message>
    <message>
        <source>  V1.2.0</source>
        <translation type="vanished">  V1.2.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="34"/>
        <source>  V2.0.0</source>
        <translation>  V2.0.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="47"/>
        <location filename="main.qml" line="470"/>
        <source>参数设置</source>
        <translation>Parameter setting</translation>
    </message>
    <message>
        <location filename="main.qml" line="181"/>
        <location filename="main.qml" line="471"/>
        <source>打开此开关选项,屏幕将恢复默认的参数配置.多媒体,滚动字幕,标题,时间和日期,系统配置参数都将恢复为默认.</source>
        <translation>If you confirm this selection, the screen will restore the default settings. All parameters including scrolling text, title, time and date and multimedia will be restored to default settings.</translation>
    </message>
    <message>
        <location filename="main.qml" line="192"/>
        <location filename="main.qml" line="433"/>
        <location filename="main.qml" line="472"/>
        <location filename="main.qml" line="478"/>
        <source>确认</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="main.qml" line="199"/>
        <location filename="main.qml" line="443"/>
        <location filename="main.qml" line="473"/>
        <location filename="main.qml" line="479"/>
        <source>取消</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="main.qml" line="234"/>
        <location filename="main.qml" line="353"/>
        <location filename="main.qml" line="474"/>
        <source>确定</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="main.qml" line="290"/>
        <location filename="main.qml" line="475"/>
        <source>点击以结束制作</source>
        <translation>Clicked and ended making</translation>
    </message>
    <message>
        <location filename="main.qml" line="312"/>
        <location filename="main.qml" line="476"/>
        <location filename="main.qml" line="513"/>
        <source>拷贝文件...</source>
        <translation>Copy file...</translation>
    </message>
    <message>
        <location filename="main.qml" line="422"/>
        <location filename="main.qml" line="477"/>
        <source>点击确认，将重新加载界面布局，Usb设备需要重新插拔!</source>
        <oldsource>点击确认，将重新加载界面布局，Usb设备需要重新插拔！.</oldsource>
        <translation>Click OK to reload the interface layout, and the Usb device needs to be reinserted!</translation>
    </message>
    <message>
        <location filename="main.qml" line="484"/>
        <source>正在生成配置参数</source>
        <translation>Generating configuration parameters...</translation>
    </message>
    <message>
        <location filename="main.qml" line="486"/>
        <source>升级盘制作成功</source>
        <translation>Upgrade disk production success</translation>
    </message>
    <message>
        <location filename="main.qml" line="501"/>
        <source>正在检查U盘...</source>
        <translation>Checking Udisk...</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="vanished">Formatting U disk.....</translation>
    </message>
</context>
</TS>
