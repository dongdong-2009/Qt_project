<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Area1</name>
    <message>
        <source>亮度&amp;音量</source>
        <translation type="vanished">亮度&amp;音量</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="45"/>
        <location filename="Area1.qml" line="359"/>
        <source>屏幕设定</source>
        <translation>屏幕设定</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="56"/>
        <location filename="Area1.qml" line="360"/>
        <source>亮度</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="61"/>
        <location filename="Area1.qml" line="361"/>
        <source>音量</source>
        <translation>音量</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="169"/>
        <location filename="Area1.qml" line="362"/>
        <source>音频</source>
        <translatorcomment>音频</translatorcomment>
        <translation>音频</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="180"/>
        <location filename="Area1.qml" line="363"/>
        <source>开</source>
        <translatorcomment>开</translatorcomment>
        <translation>开</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="200"/>
        <location filename="Area1.qml" line="364"/>
        <source>关</source>
        <translatorcomment>关</translatorcomment>
        <translation>关</translation>
    </message>
    <message>
        <source>滚动文字</source>
        <translation type="vanished">滚动文字</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="219"/>
        <location filename="Area1.qml" line="366"/>
        <source>设置滚动文字</source>
        <translation>设置滚动文字</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="248"/>
        <location filename="Area1.qml" line="376"/>
        <source>隐藏滚动文字</source>
        <translation>隐藏滚动文字</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="291"/>
        <location filename="Area1.qml" line="367"/>
        <source>设置标题</source>
        <translation>设置标题</translation>
    </message>
    <message>
        <source>显示滚动文字</source>
        <translation type="vanished">显示滚动文字</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="232"/>
        <location filename="Area1.qml" line="386"/>
        <source>请输入字幕文字</source>
        <translation>请输入字幕文字,最少2个字符</translation>
    </message>
    <message>
        <source>标题</source>
        <translation type="vanished">标题</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="322"/>
        <location filename="Area1.qml" line="385"/>
        <source>隐藏标题</source>
        <translation>隐藏标题</translation>
    </message>
    <message>
        <source>显示标题</source>
        <translation type="vanished">显示标题</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="304"/>
        <location filename="Area1.qml" line="388"/>
        <location filename="Area1.qml" line="403"/>
        <source>请输入标题文字</source>
        <translation>请输入标题文字，2到16个字符</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="399"/>
        <source>请输入滚动字幕文字</source>
        <translation>请输入滚动字幕文字</translation>
    </message>
</context>
<context>
    <name>Area2</name>
    <message>
        <source>显示时间和日期</source>
        <translation type="vanished">显示时间和日期</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="45"/>
        <location filename="Area2.qml" line="350"/>
        <source>时间格式</source>
        <translation>时间格式</translation>
    </message>
    <message>
        <source>音频</source>
        <oldsource>音频关</oldsource>
        <translation type="vanished">音频</translation>
    </message>
    <message>
        <source>音频开</source>
        <translation type="vanished">音频开</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="351"/>
        <source>12上午下午  </source>
        <translation>12上午下午</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="86"/>
        <location filename="Area2.qml" line="352"/>
        <source>24小时</source>
        <translation>24小时</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="99"/>
        <location filename="Area2.qml" line="356"/>
        <source>隐藏时间和日期</source>
        <translation>隐藏时间和日期</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="50"/>
        <location filename="Area2.qml" line="353"/>
        <source>日期格式</source>
        <translation>日期格式</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="33"/>
        <location filename="Area2.qml" line="349"/>
        <source>时间和日期</source>
        <translation>时间和日期</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="60"/>
        <source>12上午下午</source>
        <translatorcomment>12AM/PM</translatorcomment>
        <translation>12上午下午</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="71"/>
        <location filename="Area2.qml" line="354"/>
        <source>yyyy:MM:dd</source>
        <oldsource>yyyy:mm:dd</oldsource>
        <translation>yyyy:MM:dd</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="90"/>
        <location filename="Area2.qml" line="355"/>
        <source>dd:MM:yyyy</source>
        <oldsource>dd:mm:yyyy</oldsource>
        <translation>dd:MM:yyyy</translation>
    </message>
    <message>
        <source>开</source>
        <translation type="vanished">开</translation>
    </message>
    <message>
        <source>关</source>
        <translation type="vanished">关</translation>
    </message>
    <message>
        <source>mm:dd:yyyy</source>
        <translation type="vanished">mm:dd:yyyy</translation>
    </message>
    <message>
        <source>屏保</source>
        <translation type="vanished">屏保</translation>
    </message>
    <message>
        <source>一阶段周期(S)</source>
        <translation type="vanished">一阶段周期(S)</translation>
    </message>
    <message>
        <source>亮度</source>
        <translation type="vanished">亮度</translation>
    </message>
    <message>
        <source>二阶段周期(S)</source>
        <translation type="vanished">二阶段周期(S)</translation>
    </message>
</context>
<context>
    <name>Area3</name>
    <message>
        <location filename="Area3.qml" line="26"/>
        <location filename="Area3.qml" line="574"/>
        <source>多媒体更新</source>
        <translation>多媒体更新</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="47"/>
        <location filename="Area3.qml" line="575"/>
        <source>正常显示</source>
        <translation>正常显示</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="59"/>
        <location filename="Area3.qml" line="576"/>
        <source>全屏显示</source>
        <translation>全屏显示</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="89"/>
        <location filename="Area3.qml" line="589"/>
        <source>添加多媒体</source>
        <translation>添加多媒体</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="102"/>
        <location filename="Area3.qml" line="577"/>
        <source>视频</source>
        <translation>视频</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="125"/>
        <location filename="Area3.qml" line="578"/>
        <source>音频</source>
        <translation>音频</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="147"/>
        <location filename="Area3.qml" line="579"/>
        <source>图片</source>
        <translation>图片</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="197"/>
        <location filename="Area3.qml" line="580"/>
        <source>选择视频</source>
        <translation>选择视频</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="248"/>
        <location filename="Area3.qml" line="582"/>
        <source>选择音频</source>
        <translation>选择音频</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="282"/>
        <location filename="Area3.qml" line="581"/>
        <source>选择图片</source>
        <translation>选择图片</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="324"/>
        <location filename="Area3.qml" line="588"/>
        <source>间隔</source>
        <translation>间隔</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="389"/>
        <location filename="Area3.qml" line="583"/>
        <source>添加</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="395"/>
        <location filename="Area3.qml" line="584"/>
        <source>删除</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="400"/>
        <location filename="Area3.qml" line="585"/>
        <source>清空</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="414"/>
        <location filename="Area3.qml" line="590"/>
        <source>界面预览</source>
        <translation>界面预览</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="493"/>
        <location filename="Area3.qml" line="586"/>
        <source>请选择一个视频文件</source>
        <translation>请选择一个视频文件</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="504"/>
        <source>请选择一个音频文件</source>
        <translation>请选择一个音频文件</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="530"/>
        <location filename="Area3.qml" line="587"/>
        <source>请选取图片</source>
        <translation>请选取图片</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="553"/>
        <source>请选择一个视频</source>
        <translation>请选择一个视频</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="559"/>
        <source>请选择一个音频</source>
        <translation>请选择一个音频文件</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="565"/>
        <source>请选择图片</source>
        <translation>请选择图片</translation>
    </message>
</context>
<context>
    <name>Area4</name>
    <message>
        <location filename="Area4.qml" line="21"/>
        <location filename="Area4.qml" line="202"/>
        <source>语言切换</source>
        <translation>语言切换</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="38"/>
        <source>中文</source>
        <translation>中文</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="61"/>
        <source>繁體</source>
        <oldsource>繁体</oldsource>
        <translation type="unfinished">繁体</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="85"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area4.qml" line="106"/>
        <source>русский язык</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>英语</source>
        <translation type="vanished">英语</translation>
    </message>
    <message>
        <source>俄语</source>
        <translation type="vanished">俄语</translation>
    </message>
</context>
<context>
    <name>Area5</name>
    <message>
        <location filename="Area5.qml" line="15"/>
        <location filename="Area5.qml" line="277"/>
        <source>升级盘制作</source>
        <translation>升级盘制作</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="92"/>
        <location filename="Area5.qml" line="278"/>
        <source>重置为默认配置</source>
        <translation>重置为默认配置</translation>
    </message>
    <message>
        <source>界面预览</source>
        <translation type="vanished">界面预览</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="33"/>
        <location filename="Area5.qml" line="279"/>
        <source>制作升级盘</source>
        <translation>制作升级盘</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="53"/>
        <location filename="Area5.qml" line="280"/>
        <source>制作</source>
        <translation>制作</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="vanished">正在格式化U盘...</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="281"/>
        <source>拷贝文件...</source>
        <translation>拷贝文件...</translation>
    </message>
    <message>
        <source>正在生成配置参数</source>
        <translation type="vanished">正在生成配置参数</translation>
    </message>
    <message>
        <source>升级盘制作成功</source>
        <translation type="vanished">升级盘制作成功</translation>
    </message>
</context>
<context>
    <name>Horizontal_ImageOrVideo</name>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="39"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="142"/>
        <source>界面预览</source>
        <translation>界面预览</translation>
    </message>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="66"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="143"/>
        <source>横屏显示</source>
        <translation>横屏显示</translation>
    </message>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="87"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="144"/>
        <source>竖屏显示</source>
        <translation>竖屏显示</translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="39"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="66"/>
        <source>кросс экраном</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="88"/>
        <source>вертикальный экран</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModifyCheckBox</name>
    <message>
        <source>重置为默认配置</source>
        <translation type="obsolete">重置为默认配置</translation>
    </message>
</context>
<context>
    <name>RussianArea1</name>
    <message>
        <location filename="russian/RussianArea1.qml" line="54"/>
        <source>Яркость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="60"/>
        <source>Громкость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="219"/>
        <source>переходящий текст настройки</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="247"/>
        <source>Скрытие прокрутки текста</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="230"/>
        <source>Введите субтитра</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="289"/>
        <source>установить заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="318"/>
        <source>Скрытие заголовка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="301"/>
        <location filename="russian/RussianArea1.qml" line="361"/>
        <source>Введите заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="42"/>
        <source>экран настройки</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="168"/>
        <source>аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="179"/>
        <location filename="russian/RussianArea1.qml" line="199"/>
        <source>аудио гуань</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="356"/>
        <source>Введите прокрутку субтитра</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea2</name>
    <message>
        <location filename="russian/RussianArea2.qml" line="102"/>
        <source>Скрыть времни и даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="33"/>
        <source>время и дата</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="45"/>
        <source>Формат времени</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="51"/>
        <source>Формат даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="62"/>
        <source>12 Часов</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="73"/>
        <source>yyyy:MM:dd</source>
        <oldsource>yyyy:mm:dd</oldsource>
        <translation type="unfinished">yyyy:mm:dd</translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="88"/>
        <source>24 Часов</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="92"/>
        <source>dd:MM:yyyy</source>
        <oldsource>dd:mm:yyyy</oldsource>
        <translation type="unfinished">dd:mm:yyyy</translation>
    </message>
    <message>
        <source>mm:dd:yyyy</source>
        <translation type="obsolete">mm:dd:yyyy</translation>
    </message>
</context>
<context>
    <name>RussianArea3</name>
    <message>
        <location filename="russian/RussianArea3.qml" line="26"/>
        <source>Обновление мультимедиа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="48"/>
        <source>Нормальная индикация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="62"/>
        <source>Полноэкранная индикация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="85"/>
        <source>Добавить мультимедиа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="99"/>
        <source>Видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="122"/>
        <source>аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="145"/>
        <source>Картина</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="196"/>
        <source>Выбор видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="247"/>
        <location filename="russian/RussianArea3.qml" line="513"/>
        <location filename="russian/RussianArea3.qml" line="564"/>
        <source>выбрать аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="282"/>
        <source>Выбор картины</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="324"/>
        <source>интервал</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="396"/>
        <source>Добавить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="402"/>
        <source>Удалить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="408"/>
        <source>Очистить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="422"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="501"/>
        <location filename="russian/RussianArea3.qml" line="557"/>
        <source>Выберите видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="540"/>
        <location filename="russian/RussianArea3.qml" line="570"/>
        <source>Выберите картину</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="579"/>
        <source>多媒体更新</source>
        <translation type="unfinished">多媒体更新</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="580"/>
        <source>正常显示</source>
        <translation type="unfinished">正常显示</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="581"/>
        <source>全屏显示</source>
        <translation type="unfinished">全屏显示</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="582"/>
        <source>视频</source>
        <translation type="unfinished">视频</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="583"/>
        <source>音频</source>
        <translation type="unfinished">音频</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="584"/>
        <source>图片</source>
        <translation type="unfinished">图片</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="585"/>
        <source>选择视频</source>
        <translation type="unfinished">选择视频</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="586"/>
        <source>选择图片</source>
        <translation type="unfinished">选择图片</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="587"/>
        <source>选择音频</source>
        <translation type="unfinished">选择音频</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="588"/>
        <source>添加</source>
        <translation type="unfinished">添加</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="589"/>
        <source>删除</source>
        <translation type="unfinished">删除</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="590"/>
        <source>清空</source>
        <translation type="unfinished">清空</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="591"/>
        <source>请选择一个视频文件</source>
        <translation type="unfinished">请选择一个视频文件</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="592"/>
        <source>请选取图片</source>
        <translation type="unfinished">请选取图片</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="593"/>
        <source>间隔</source>
        <translation type="unfinished">间隔</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="594"/>
        <source>添加多媒体</source>
        <translation type="unfinished">添加多媒体</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="595"/>
        <source>界面预览</source>
        <translation type="unfinished">界面预览</translation>
    </message>
</context>
<context>
    <name>RussianArea4</name>
    <message>
        <location filename="russian/RussianArea4.qml" line="22"/>
        <source>Переключатель языка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="39"/>
        <source>中文</source>
        <translation type="unfinished">中文</translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="61"/>
        <source>繁體</source>
        <translation type="unfinished">繁体</translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="84"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="105"/>
        <source>Русский язык</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea5</name>
    <message>
        <location filename="russian/RussianArea5.qml" line="16"/>
        <source>Поделка обновления диска </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="95"/>
        <source>Вновь установления настройки по умолчанию</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="38"/>
        <source>Поделка обновления диска</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="58"/>
        <source>Поделка</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianMain</name>
    <message>
        <location filename="russian/RussianMain.qml" line="34"/>
        <source>MediaScreen Content management</source>
        <oldsource>MediaScreenHelper</oldsource>
        <translation type="unfinished">MediaScreenHelper</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="obsolete">V1.7.0</translation>
    </message>
    <message>
        <source>  V1.2.0</source>
        <translation type="obsolete">V1.2.0</translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="34"/>
        <source>  V2.0.0</source>
        <translation type="unfinished">V2.0.0</translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="48"/>
        <source>Настройка параметров</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="179"/>
        <source>Включите этот параметр переключателя, на экране будет восстановлена настройка параметров по умолчанию. Мультимедиа, прокрутка субтитров, заголовок, времени и даты, параметры конфигурации системы буду
т восстановлены по умолчанию.</source>
        <oldsource>Включите этот параметр переключателя, на экране будет восстановлена настройка параметров по умолчанию. Мультимедиа, прокрутка субтитров, заголовок, времени и даты, параметры конфигурации системы буду
т восстановлены по умолчанию.</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="192"/>
        <location filename="russian/RussianMain.qml" line="236"/>
        <location filename="russian/RussianMain.qml" line="388"/>
        <source>Уточнение</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="200"/>
        <location filename="russian/RussianMain.qml" line="398"/>
        <source>Отмена</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="294"/>
        <source>Нажмите, чтобы закончить поделку</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="316"/>
        <source>Копирование файла...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="376"/>
        <source>Нажмите, чтобы подтвердить.Размещение страницы будет перезагружен.Необходимо перезагрузить USB!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="425"/>
        <source>Создание параметров конфигурации</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="428"/>
        <source>Успех в поделке обновлении диска</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="444"/>
        <source>проверить диска...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="455"/>
        <source>拷贝文件...</source>
        <translation type="unfinished">拷贝文件...</translation>
    </message>
</context>
<context>
    <name>Vertical_ImageOrVideo</name>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="38"/>
        <location filename="Vertical_ImageOrVideo.qml" line="131"/>
        <source>界面预览</source>
        <translation>界面预览</translation>
    </message>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="63"/>
        <location filename="Vertical_ImageOrVideo.qml" line="132"/>
        <source>横屏显示</source>
        <translation>横屏显示</translation>
    </message>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="91"/>
        <location filename="Vertical_ImageOrVideo.qml" line="133"/>
        <source>竖屏显示</source>
        <translation>竖屏显示</translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="38"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="62"/>
        <source>кросс экраном</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="89"/>
        <source>вертикальный экран</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="34"/>
        <source>MediaScreen Content management</source>
        <oldsource>MediaScreenHelper</oldsource>
        <translation>MediaScreenHelper</translation>
    </message>
    <message>
        <source>  V1.6.0</source>
        <translation type="vanished">V1.6.0</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="vanished">V1.7.0</translation>
    </message>
    <message>
        <source>  V1.2.0</source>
        <translation type="vanished">V1.2.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="34"/>
        <source>  V2.0.0</source>
        <translation>V2.0.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="47"/>
        <location filename="main.qml" line="470"/>
        <source>参数设置</source>
        <translation>参数设置</translation>
    </message>
    <message>
        <location filename="main.qml" line="181"/>
        <location filename="main.qml" line="471"/>
        <source>打开此开关选项,屏幕将恢复默认的参数配置.多媒体,滚动字幕,标题,时间和日期,系统配置参数都将恢复为默认.</source>
        <translation>打开此开关选项,屏幕将恢复默认的参数配置.多媒体,滚动字幕,标题,时间和日期,系统配置参数都将恢复为默认</translation>
    </message>
    <message>
        <location filename="main.qml" line="192"/>
        <location filename="main.qml" line="433"/>
        <location filename="main.qml" line="472"/>
        <location filename="main.qml" line="478"/>
        <source>确认</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="main.qml" line="199"/>
        <location filename="main.qml" line="443"/>
        <location filename="main.qml" line="473"/>
        <location filename="main.qml" line="479"/>
        <source>取消</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="main.qml" line="234"/>
        <location filename="main.qml" line="353"/>
        <location filename="main.qml" line="474"/>
        <source>确定</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="main.qml" line="290"/>
        <location filename="main.qml" line="475"/>
        <source>点击以结束制作</source>
        <translation>点击以结束制作</translation>
    </message>
    <message>
        <location filename="main.qml" line="312"/>
        <location filename="main.qml" line="476"/>
        <location filename="main.qml" line="513"/>
        <source>拷贝文件...</source>
        <translation>拷贝文件...</translation>
    </message>
    <message>
        <location filename="main.qml" line="422"/>
        <location filename="main.qml" line="477"/>
        <source>点击确认，将重新加载界面布局，Usb设备需要重新插拔!</source>
        <oldsource>点击确认，将重新加载界面布局，Usb设备需要重新插拔！.</oldsource>
        <translation>点击确认，将重新加载界面布局，Usb设备需要重新插拔！</translation>
    </message>
    <message>
        <location filename="main.qml" line="501"/>
        <source>正在检查U盘...</source>
        <translation></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <location filename="main.qml" line="484"/>
        <source>正在生成配置参数</source>
        <translation>正在生成配置参数</translation>
    </message>
    <message>
        <location filename="main.qml" line="486"/>
        <source>升级盘制作成功</source>
        <translation>升级盘制作成功</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="vanished">正在格式化U盘...</translation>
    </message>
</context>
</TS>
