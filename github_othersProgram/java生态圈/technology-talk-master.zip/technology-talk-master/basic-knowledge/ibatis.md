## ibatis

---

[MyBatis 动态 SQL 底层原理分析](http://mp.weixin.qq.com/s/BLY1HZUtmYA_w1_MZfcYRQ)



####简介

ibatis已经不再维护，现在基本采用myibatis


