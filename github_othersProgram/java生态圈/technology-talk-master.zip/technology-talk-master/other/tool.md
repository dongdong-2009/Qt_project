### 常用软件工具
---

* [Lombok安装](http://www.blogjava.net/fancydeepin/archive/2012/07/12/382933.html)
* [HTTPS 抓包工具-----charles](http://blog.vetcafe.net/2013/12/charlesproxyiphonehttps.html)
* [自动生成Restful api接口规范文档-----swagger](swagger.md)
* [模拟构造HTTP请求-----postman](https://www.getpostman.com/apps)
* [头脑风暴软件-----xmind](http://www.xmindchina.net/)
* [统一建模语言画图------StarUML](http://www.chinapyg.com/forum.php?mod=viewthread&tid=79022&page=1)
