## 事务

---


* [分布式系统常见的事务处理机制](https://mp.weixin.qq.com/s/ja0VRPkfHL9dtOP_PxwxKw)
