## 其它

---

### 基础

* 	[mysql中bigint、int、mediumint、smallint 和 tinyint的取值范围](bigint类型.md)


### 业界动态

* 	[NoSQL 没毛病，为什么 MySQL 还是“王”：8 篇值得回顾的技术热文](https://mp.weixin.qq.com/s/g0eqJpZoHDh-c2XdKJkFXw)
* 	[阿里下一代数据库技术：把数据库装入容器不再是神话](https://mp.weixin.qq.com/s/AIZQ5-F5AngdIESNCXngWw)
