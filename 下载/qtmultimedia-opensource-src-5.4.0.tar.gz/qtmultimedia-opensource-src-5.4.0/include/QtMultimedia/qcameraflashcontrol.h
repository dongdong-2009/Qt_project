#include "../../src/multimedia/controls/qcameraflashcontrol.h"
