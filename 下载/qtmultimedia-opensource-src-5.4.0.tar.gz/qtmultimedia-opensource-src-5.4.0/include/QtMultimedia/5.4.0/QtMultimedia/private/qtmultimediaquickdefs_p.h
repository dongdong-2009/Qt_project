#include "../../../../../src/multimedia/qtmultimediaquicktools_headers/qtmultimediaquickdefs_p.h"
