#include "../../../../../src/multimedia/gsttools_headers/qgstreamervideoinputdevicecontrol_p.h"
