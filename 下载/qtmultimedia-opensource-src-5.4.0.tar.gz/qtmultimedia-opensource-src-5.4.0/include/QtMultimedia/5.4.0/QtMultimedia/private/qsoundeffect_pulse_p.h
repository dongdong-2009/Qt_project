#include "../../../../../src/multimedia/audio/qsoundeffect_pulse_p.h"
