#include "../../src/multimedia/controls/qcameracapturebufferformatcontrol.h"
