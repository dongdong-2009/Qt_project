#include "../../src/multimedia/controls/qcameracontrol.h"
