#include "../../src/multimedia/camera/qcameraimagecapture.h"
