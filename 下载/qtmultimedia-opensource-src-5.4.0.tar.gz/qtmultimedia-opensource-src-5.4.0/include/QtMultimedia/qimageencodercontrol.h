#include "../../src/multimedia/controls/qimageencodercontrol.h"
