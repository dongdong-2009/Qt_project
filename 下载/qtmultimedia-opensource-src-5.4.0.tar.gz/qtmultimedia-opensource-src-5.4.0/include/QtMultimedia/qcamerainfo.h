#include "../../src/multimedia/camera/qcamerainfo.h"
