#include "../../src/multimedia/qmediatimerange.h"
