#include "../../src/multimedia/qmediaserviceproviderplugin.h"
