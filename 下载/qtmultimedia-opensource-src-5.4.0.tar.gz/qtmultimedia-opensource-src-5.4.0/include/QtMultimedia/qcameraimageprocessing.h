#include "../../src/multimedia/camera/qcameraimageprocessing.h"
