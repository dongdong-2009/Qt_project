#include "../../src/multimedia/controls/qcameraimagecapturecontrol.h"
