#include "../../src/multimedia/qmediabindableinterface.h"
