#include "../../src/multimedia/controls/qcameraviewfindersettingscontrol.h"
