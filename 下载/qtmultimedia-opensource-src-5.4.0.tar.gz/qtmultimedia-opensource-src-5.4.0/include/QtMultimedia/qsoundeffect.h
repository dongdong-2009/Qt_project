#include "../../src/multimedia/audio/qsoundeffect.h"
