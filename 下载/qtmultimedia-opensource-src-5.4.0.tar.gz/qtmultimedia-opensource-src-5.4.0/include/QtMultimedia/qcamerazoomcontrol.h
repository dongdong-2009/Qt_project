#include "../../src/multimedia/controls/qcamerazoomcontrol.h"
