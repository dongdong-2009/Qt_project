/****************************************************************************
** Meta object code from reading C++ file 'videoformatconvert.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../videoformatconvert.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'videoformatconvert.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_videoformatConvert_t {
    QByteArrayData data[14];
    char stringdata0[164];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_videoformatConvert_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_videoformatConvert_t qt_meta_stringdata_videoformatConvert = {
    {
QT_MOC_LITERAL(0, 0, 18), // "videoformatConvert"
QT_MOC_LITERAL(1, 19, 18), // "convertVideoFormat"
QT_MOC_LITERAL(2, 38, 0), // ""
QT_MOC_LITERAL(3, 39, 12), // "getVideoInfo"
QT_MOC_LITERAL(4, 52, 8), // "filename"
QT_MOC_LITERAL(5, 61, 13), // "videoFileSize"
QT_MOC_LITERAL(6, 75, 13), // "videoPathName"
QT_MOC_LITERAL(7, 89, 12), // "getTotalTime"
QT_MOC_LITERAL(8, 102, 5), // "ttime"
QT_MOC_LITERAL(9, 108, 12), // "getFenBianLv"
QT_MOC_LITERAL(10, 121, 9), // "fenbianlv"
QT_MOC_LITERAL(11, 131, 10), // "getSeconds"
QT_MOC_LITERAL(12, 142, 5), // "ptime"
QT_MOC_LITERAL(13, 148, 15) // "getRevertString"

    },
    "videoformatConvert\0convertVideoFormat\0"
    "\0getVideoInfo\0filename\0videoFileSize\0"
    "videoPathName\0getTotalTime\0ttime\0"
    "getFenBianLv\0fenbianlv\0getSeconds\0"
    "ptime\0getRevertString"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_videoformatConvert[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   49,    2, 0x0a /* Public */,
       3,    1,   50,    2, 0x0a /* Public */,
       5,    1,   53,    2, 0x0a /* Public */,
       7,    1,   56,    2, 0x0a /* Public */,
       9,    1,   59,    2, 0x0a /* Public */,
      11,    1,   62,    2, 0x0a /* Public */,
      13,    0,   65,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    4,
    QMetaType::QReal, QMetaType::QString,    6,
    QMetaType::QString, QMetaType::QString,    8,
    QMetaType::QString, QMetaType::QString,   10,
    QMetaType::LongLong, QMetaType::QString,   12,
    QMetaType::QString,

       0        // eod
};

void videoformatConvert::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        videoformatConvert *_t = static_cast<videoformatConvert *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->convertVideoFormat(); break;
        case 1: _t->getVideoInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 2: { qreal _r = _t->videoFileSize((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< qreal*>(_a[0]) = _r; }  break;
        case 3: { QString _r = _t->getTotalTime((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 4: { QString _r = _t->getFenBianLv((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 5: { qint64 _r = _t->getSeconds((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< qint64*>(_a[0]) = _r; }  break;
        case 6: { QString _r = _t->getRevertString();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        default: ;
        }
    }
}

const QMetaObject videoformatConvert::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_videoformatConvert.data,
      qt_meta_data_videoformatConvert,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *videoformatConvert::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *videoformatConvert::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_videoformatConvert.stringdata0))
        return static_cast<void*>(const_cast< videoformatConvert*>(this));
    return QObject::qt_metacast(_clname);
}

int videoformatConvert::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
