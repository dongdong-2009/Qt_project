/****************************************************************************
** Meta object code from reading C++ file 'configureholder.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.8.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../configureholder.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'configureholder.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.8.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ConfigureHolder_t {
    QByteArrayData data[88];
    char stringdata0[1306];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ConfigureHolder_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ConfigureHolder_t qt_meta_stringdata_ConfigureHolder = {
    {
QT_MOC_LITERAL(0, 0, 15), // "ConfigureHolder"
QT_MOC_LITERAL(1, 16, 16), // "copyFileProgress"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 3), // "pro"
QT_MOC_LITERAL(4, 38, 19), // "resetDefaultClicked"
QT_MOC_LITERAL(5, 58, 13), // "resetCanceled"
QT_MOC_LITERAL(6, 72, 17), // "showPreviewSignal"
QT_MOC_LITERAL(7, 90, 19), // "previewCheckedFalse"
QT_MOC_LITERAL(8, 110, 17), // "startPicAnimation"
QT_MOC_LITERAL(9, 128, 19), // "isFullScreenChanges"
QT_MOC_LITERAL(10, 148, 6), // "isfull"
QT_MOC_LITERAL(11, 155, 23), // "horizontalAudioAutoPlay"
QT_MOC_LITERAL(12, 179, 33), // "horizontalFullscreenAudioAuto..."
QT_MOC_LITERAL(13, 213, 21), // "verticalAudioAutoPlay"
QT_MOC_LITERAL(14, 235, 31), // "verticalFullscreenAudioAutoPlay"
QT_MOC_LITERAL(15, 267, 16), // "stopAllAudioPlay"
QT_MOC_LITERAL(16, 284, 25), // "startPlayAfterCloseNormal"
QT_MOC_LITERAL(17, 310, 29), // "startPlayAfterCloseFullScreen"
QT_MOC_LITERAL(18, 340, 9), // "createXml"
QT_MOC_LITERAL(19, 350, 3), // "dir"
QT_MOC_LITERAL(20, 354, 15), // "clearParameters"
QT_MOC_LITERAL(21, 370, 9), // "startJobs"
QT_MOC_LITERAL(22, 380, 9), // "orderFile"
QT_MOC_LITERAL(23, 390, 15), // "copyReourceFile"
QT_MOC_LITERAL(24, 406, 3), // "src"
QT_MOC_LITERAL(25, 410, 3), // "dst"
QT_MOC_LITERAL(26, 414, 13), // "copyFileMulti"
QT_MOC_LITERAL(27, 428, 11), // "GetFilePath"
QT_MOC_LITERAL(28, 440, 9), // "pFilePath"
QT_MOC_LITERAL(29, 450, 16), // "copyProgressMult"
QT_MOC_LITERAL(30, 467, 2), // "id"
QT_MOC_LITERAL(31, 470, 9), // "copyBytes"
QT_MOC_LITERAL(32, 480, 11), // "jobFinished"
QT_MOC_LITERAL(33, 492, 11), // "resetScreen"
QT_MOC_LITERAL(34, 504, 7), // "isReset"
QT_MOC_LITERAL(35, 512, 17), // "sendCheckedSignal"
QT_MOC_LITERAL(36, 530, 18), // "sendCanceledSignal"
QT_MOC_LITERAL(37, 549, 15), // "sendShowPreview"
QT_MOC_LITERAL(38, 565, 23), // "sendPreviewCheckedFalse"
QT_MOC_LITERAL(39, 589, 21), // "sendStartPicAnimation"
QT_MOC_LITERAL(40, 611, 22), // "sendIsFullScreenSignal"
QT_MOC_LITERAL(41, 634, 6), // "isflag"
QT_MOC_LITERAL(42, 641, 22), // "sendHorizontalAutoPlay"
QT_MOC_LITERAL(43, 664, 20), // "sendVerticalAutoPlay"
QT_MOC_LITERAL(44, 685, 17), // "sendStopAudioPlay"
QT_MOC_LITERAL(45, 703, 18), // "sendPlayAfterClose"
QT_MOC_LITERAL(46, 722, 16), // "updateMultiMedia"
QT_MOC_LITERAL(47, 739, 21), // "isMediaContentEnabled"
QT_MOC_LITERAL(48, 761, 14), // "videoOrPicture"
QT_MOC_LITERAL(49, 776, 7), // "isAudio"
QT_MOC_LITERAL(50, 784, 12), // "isfullscreen"
QT_MOC_LITERAL(51, 797, 5), // "paths"
QT_MOC_LITERAL(52, 803, 14), // "retPicturePath"
QT_MOC_LITERAL(53, 818, 20), // "updateParameterBasic"
QT_MOC_LITERAL(54, 839, 19), // "bConfigureParameter"
QT_MOC_LITERAL(55, 859, 17), // "bBrightnessVolume"
QT_MOC_LITERAL(56, 877, 11), // "bScrollText"
QT_MOC_LITERAL(57, 889, 6), // "bTitle"
QT_MOC_LITERAL(58, 896, 9), // "bDateTime"
QT_MOC_LITERAL(59, 906, 8), // "bStandby"
QT_MOC_LITERAL(60, 915, 12), // "isScrollText"
QT_MOC_LITERAL(61, 928, 7), // "isTitle"
QT_MOC_LITERAL(62, 936, 10), // "isDateTime"
QT_MOC_LITERAL(63, 947, 8), // "audioSel"
QT_MOC_LITERAL(64, 956, 21), // "updateParameterBasic1"
QT_MOC_LITERAL(65, 978, 10), // "scrollFlag"
QT_MOC_LITERAL(66, 989, 9), // "titleFlag"
QT_MOC_LITERAL(67, 999, 21), // "updateParameterBasic2"
QT_MOC_LITERAL(68, 1021, 8), // "timeFlag"
QT_MOC_LITERAL(69, 1030, 9), // "audioFlag"
QT_MOC_LITERAL(70, 1040, 22), // "updateBrightnessVolume"
QT_MOC_LITERAL(71, 1063, 11), // "vBrightness"
QT_MOC_LITERAL(72, 1075, 7), // "vVolume"
QT_MOC_LITERAL(73, 1083, 16), // "updateScrollText"
QT_MOC_LITERAL(74, 1100, 11), // "vScrollText"
QT_MOC_LITERAL(75, 1112, 11), // "updateTitle"
QT_MOC_LITERAL(76, 1124, 6), // "vTitle"
QT_MOC_LITERAL(77, 1131, 14), // "updateDateTime"
QT_MOC_LITERAL(78, 1146, 11), // "vTimeFormat"
QT_MOC_LITERAL(79, 1158, 11), // "vDateFormat"
QT_MOC_LITERAL(80, 1170, 13), // "updateStandby"
QT_MOC_LITERAL(81, 1184, 15), // "vStage1Interval"
QT_MOC_LITERAL(82, 1200, 17), // "vStage1Brightness"
QT_MOC_LITERAL(83, 1218, 15), // "vStage2Interval"
QT_MOC_LITERAL(84, 1234, 17), // "vStage2Brightness"
QT_MOC_LITERAL(85, 1252, 21), // "updatePictureInterval"
QT_MOC_LITERAL(86, 1274, 16), // "vPictureInterval"
QT_MOC_LITERAL(87, 1291, 14) // "getPicInterval"

    },
    "ConfigureHolder\0copyFileProgress\0\0pro\0"
    "resetDefaultClicked\0resetCanceled\0"
    "showPreviewSignal\0previewCheckedFalse\0"
    "startPicAnimation\0isFullScreenChanges\0"
    "isfull\0horizontalAudioAutoPlay\0"
    "horizontalFullscreenAudioAutoPlay\0"
    "verticalAudioAutoPlay\0"
    "verticalFullscreenAudioAutoPlay\0"
    "stopAllAudioPlay\0startPlayAfterCloseNormal\0"
    "startPlayAfterCloseFullScreen\0createXml\0"
    "dir\0clearParameters\0startJobs\0orderFile\0"
    "copyReourceFile\0src\0dst\0copyFileMulti\0"
    "GetFilePath\0pFilePath\0copyProgressMult\0"
    "id\0copyBytes\0jobFinished\0resetScreen\0"
    "isReset\0sendCheckedSignal\0sendCanceledSignal\0"
    "sendShowPreview\0sendPreviewCheckedFalse\0"
    "sendStartPicAnimation\0sendIsFullScreenSignal\0"
    "isflag\0sendHorizontalAutoPlay\0"
    "sendVerticalAutoPlay\0sendStopAudioPlay\0"
    "sendPlayAfterClose\0updateMultiMedia\0"
    "isMediaContentEnabled\0videoOrPicture\0"
    "isAudio\0isfullscreen\0paths\0retPicturePath\0"
    "updateParameterBasic\0bConfigureParameter\0"
    "bBrightnessVolume\0bScrollText\0bTitle\0"
    "bDateTime\0bStandby\0isScrollText\0isTitle\0"
    "isDateTime\0audioSel\0updateParameterBasic1\0"
    "scrollFlag\0titleFlag\0updateParameterBasic2\0"
    "timeFlag\0audioFlag\0updateBrightnessVolume\0"
    "vBrightness\0vVolume\0updateScrollText\0"
    "vScrollText\0updateTitle\0vTitle\0"
    "updateDateTime\0vTimeFormat\0vDateFormat\0"
    "updateStandby\0vStage1Interval\0"
    "vStage1Brightness\0vStage2Interval\0"
    "vStage2Brightness\0updatePictureInterval\0"
    "vPictureInterval\0getPicInterval"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ConfigureHolder[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      46,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      14,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  244,    2, 0x06 /* Public */,
       4,    0,  247,    2, 0x06 /* Public */,
       5,    0,  248,    2, 0x06 /* Public */,
       6,    0,  249,    2, 0x06 /* Public */,
       7,    0,  250,    2, 0x06 /* Public */,
       8,    0,  251,    2, 0x06 /* Public */,
       9,    1,  252,    2, 0x06 /* Public */,
      11,    0,  255,    2, 0x06 /* Public */,
      12,    0,  256,    2, 0x06 /* Public */,
      13,    0,  257,    2, 0x06 /* Public */,
      14,    0,  258,    2, 0x06 /* Public */,
      15,    0,  259,    2, 0x06 /* Public */,
      16,    0,  260,    2, 0x06 /* Public */,
      17,    0,  261,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      18,    1,  262,    2, 0x0a /* Public */,
      20,    0,  265,    2, 0x0a /* Public */,
      21,    0,  266,    2, 0x0a /* Public */,
      22,    1,  267,    2, 0x0a /* Public */,
      23,    2,  270,    2, 0x0a /* Public */,
      26,    2,  275,    2, 0x0a /* Public */,
      27,    1,  280,    2, 0x0a /* Public */,
      29,    2,  283,    2, 0x0a /* Public */,
      32,    1,  288,    2, 0x0a /* Public */,
      33,    1,  291,    2, 0x0a /* Public */,
      35,    0,  294,    2, 0x0a /* Public */,
      36,    0,  295,    2, 0x0a /* Public */,
      37,    0,  296,    2, 0x0a /* Public */,
      38,    0,  297,    2, 0x0a /* Public */,
      39,    0,  298,    2, 0x0a /* Public */,
      40,    1,  299,    2, 0x0a /* Public */,
      42,    1,  302,    2, 0x0a /* Public */,
      43,    1,  305,    2, 0x0a /* Public */,
      44,    0,  308,    2, 0x0a /* Public */,
      45,    1,  309,    2, 0x0a /* Public */,
      46,    5,  312,    2, 0x0a /* Public */,
      52,    1,  323,    2, 0x0a /* Public */,
      53,   10,  326,    2, 0x0a /* Public */,
      64,    8,  347,    2, 0x0a /* Public */,
      67,    7,  364,    2, 0x0a /* Public */,
      70,    2,  379,    2, 0x0a /* Public */,
      73,    1,  384,    2, 0x0a /* Public */,
      75,    1,  387,    2, 0x0a /* Public */,
      77,    2,  390,    2, 0x0a /* Public */,
      80,    4,  395,    2, 0x0a /* Public */,
      85,    1,  404,    2, 0x0a /* Public */,
      87,    0,  407,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Bool, QMetaType::QString,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   19,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   24,   25,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   24,   25,
    QMetaType::QString, QMetaType::QString,   28,
    QMetaType::Void, QMetaType::Int, QMetaType::LongLong,   30,   31,
    QMetaType::Void, QMetaType::Int,   30,
    QMetaType::Bool, QMetaType::Bool,   34,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   41,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   10,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::QString,   47,   48,   49,   50,   51,
    QMetaType::QVariant, QMetaType::QString,   51,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool,   54,   55,   56,   57,   58,   59,   60,   61,   62,   63,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int,   54,   55,   56,   57,   60,   61,   65,   66,
    QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Bool, QMetaType::Int, QMetaType::Int,   54,   58,   59,   62,   63,   68,   69,
    QMetaType::Bool, QMetaType::Int, QMetaType::Int,   71,   72,
    QMetaType::Bool, QMetaType::QString,   74,
    QMetaType::Bool, QMetaType::QString,   76,
    QMetaType::Bool, QMetaType::QString, QMetaType::QString,   78,   79,
    QMetaType::Bool, QMetaType::UInt, QMetaType::UChar, QMetaType::UInt, QMetaType::UChar,   81,   82,   83,   84,
    QMetaType::Bool, QMetaType::Int,   86,
    QMetaType::Int,

       0        // eod
};

void ConfigureHolder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        ConfigureHolder *_t = static_cast<ConfigureHolder *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->copyFileProgress((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->resetDefaultClicked(); break;
        case 2: _t->resetCanceled(); break;
        case 3: _t->showPreviewSignal(); break;
        case 4: _t->previewCheckedFalse(); break;
        case 5: _t->startPicAnimation(); break;
        case 6: _t->isFullScreenChanges((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 7: _t->horizontalAudioAutoPlay(); break;
        case 8: _t->horizontalFullscreenAudioAutoPlay(); break;
        case 9: _t->verticalAudioAutoPlay(); break;
        case 10: _t->verticalFullscreenAudioAutoPlay(); break;
        case 11: _t->stopAllAudioPlay(); break;
        case 12: _t->startPlayAfterCloseNormal(); break;
        case 13: _t->startPlayAfterCloseFullScreen(); break;
        case 14: { bool _r = _t->createXml((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 15: _t->clearParameters(); break;
        case 16: _t->startJobs(); break;
        case 17: _t->orderFile((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 18: { bool _r = _t->copyReourceFile((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 19: { bool _r = _t->copyFileMulti((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 20: { QString _r = _t->GetFilePath((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = _r; }  break;
        case 21: _t->copyProgressMult((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< qint64(*)>(_a[2]))); break;
        case 22: _t->jobFinished((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 23: { bool _r = _t->resetScreen((*reinterpret_cast< bool(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 24: _t->sendCheckedSignal(); break;
        case 25: _t->sendCanceledSignal(); break;
        case 26: _t->sendShowPreview(); break;
        case 27: _t->sendPreviewCheckedFalse(); break;
        case 28: _t->sendStartPicAnimation(); break;
        case 29: _t->sendIsFullScreenSignal((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->sendHorizontalAutoPlay((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 31: _t->sendVerticalAutoPlay((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->sendStopAudioPlay(); break;
        case 33: _t->sendPlayAfterClose((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 34: { bool _r = _t->updateMultiMedia((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 35: { QVariant _r = _t->retPicturePath((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< QVariant*>(_a[0]) = _r; }  break;
        case 36: { bool _r = _t->updateParameterBasic((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6])),(*reinterpret_cast< bool(*)>(_a[7])),(*reinterpret_cast< bool(*)>(_a[8])),(*reinterpret_cast< bool(*)>(_a[9])),(*reinterpret_cast< bool(*)>(_a[10])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 37: { bool _r = _t->updateParameterBasic1((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< bool(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])),(*reinterpret_cast< int(*)>(_a[8])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 38: { bool _r = _t->updateParameterBasic2((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< bool(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5])),(*reinterpret_cast< int(*)>(_a[6])),(*reinterpret_cast< int(*)>(_a[7])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 39: { bool _r = _t->updateBrightnessVolume((*reinterpret_cast< qint32(*)>(_a[1])),(*reinterpret_cast< qint32(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 40: { bool _r = _t->updateScrollText((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 41: { bool _r = _t->updateTitle((*reinterpret_cast< QString(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 42: { bool _r = _t->updateDateTime((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 43: { bool _r = _t->updateStandby((*reinterpret_cast< quint32(*)>(_a[1])),(*reinterpret_cast< quint8(*)>(_a[2])),(*reinterpret_cast< quint32(*)>(_a[3])),(*reinterpret_cast< quint8(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 44: { bool _r = _t->updatePictureInterval((*reinterpret_cast< qint32(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        case 45: { int _r = _t->getPicInterval();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (ConfigureHolder::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::copyFileProgress)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::resetDefaultClicked)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::resetCanceled)) {
                *result = 2;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::showPreviewSignal)) {
                *result = 3;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::previewCheckedFalse)) {
                *result = 4;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::startPicAnimation)) {
                *result = 5;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::isFullScreenChanges)) {
                *result = 6;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::horizontalAudioAutoPlay)) {
                *result = 7;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::horizontalFullscreenAudioAutoPlay)) {
                *result = 8;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::verticalAudioAutoPlay)) {
                *result = 9;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::verticalFullscreenAudioAutoPlay)) {
                *result = 10;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::stopAllAudioPlay)) {
                *result = 11;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::startPlayAfterCloseNormal)) {
                *result = 12;
                return;
            }
        }
        {
            typedef void (ConfigureHolder::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&ConfigureHolder::startPlayAfterCloseFullScreen)) {
                *result = 13;
                return;
            }
        }
    }
}

const QMetaObject ConfigureHolder::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_ConfigureHolder.data,
      qt_meta_data_ConfigureHolder,  qt_static_metacall, Q_NULLPTR, Q_NULLPTR}
};


const QMetaObject *ConfigureHolder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ConfigureHolder::qt_metacast(const char *_clname)
{
    if (!_clname) return Q_NULLPTR;
    if (!strcmp(_clname, qt_meta_stringdata_ConfigureHolder.stringdata0))
        return static_cast<void*>(const_cast< ConfigureHolder*>(this));
    return QObject::qt_metacast(_clname);
}

int ConfigureHolder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 46)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 46;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 46)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 46;
    }
    return _id;
}

// SIGNAL 0
void ConfigureHolder::copyFileProgress(int _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ConfigureHolder::resetDefaultClicked()
{
    QMetaObject::activate(this, &staticMetaObject, 1, Q_NULLPTR);
}

// SIGNAL 2
void ConfigureHolder::resetCanceled()
{
    QMetaObject::activate(this, &staticMetaObject, 2, Q_NULLPTR);
}

// SIGNAL 3
void ConfigureHolder::showPreviewSignal()
{
    QMetaObject::activate(this, &staticMetaObject, 3, Q_NULLPTR);
}

// SIGNAL 4
void ConfigureHolder::previewCheckedFalse()
{
    QMetaObject::activate(this, &staticMetaObject, 4, Q_NULLPTR);
}

// SIGNAL 5
void ConfigureHolder::startPicAnimation()
{
    QMetaObject::activate(this, &staticMetaObject, 5, Q_NULLPTR);
}

// SIGNAL 6
void ConfigureHolder::isFullScreenChanges(bool _t1)
{
    void *_a[] = { Q_NULLPTR, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void ConfigureHolder::horizontalAudioAutoPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 7, Q_NULLPTR);
}

// SIGNAL 8
void ConfigureHolder::horizontalFullscreenAudioAutoPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 8, Q_NULLPTR);
}

// SIGNAL 9
void ConfigureHolder::verticalAudioAutoPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 9, Q_NULLPTR);
}

// SIGNAL 10
void ConfigureHolder::verticalFullscreenAudioAutoPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 10, Q_NULLPTR);
}

// SIGNAL 11
void ConfigureHolder::stopAllAudioPlay()
{
    QMetaObject::activate(this, &staticMetaObject, 11, Q_NULLPTR);
}

// SIGNAL 12
void ConfigureHolder::startPlayAfterCloseNormal()
{
    QMetaObject::activate(this, &staticMetaObject, 12, Q_NULLPTR);
}

// SIGNAL 13
void ConfigureHolder::startPlayAfterCloseFullScreen()
{
    QMetaObject::activate(this, &staticMetaObject, 13, Q_NULLPTR);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
