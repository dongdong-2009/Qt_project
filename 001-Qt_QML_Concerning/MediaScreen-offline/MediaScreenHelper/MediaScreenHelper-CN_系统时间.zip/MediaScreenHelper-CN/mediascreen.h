#ifndef MEDIASCREEN_H
#define MEDIASCREEN_H

#include <QObject>
#include "usbeventfilter.h"
#include "configureholder.h"
#include "ctranslator.h"
#include <QQmlContext>
#include <QQmlApplicationEngine>
#include "usbeventfilter.h"
#include <QVariant>
#include <QString>
#include <QDateTime>
class MediaScreen : public QObject
{
    Q_OBJECT
public:
    explicit MediaScreen(QObject *parent = 0);
    void init();
    ~MediaScreen();
    UsbEventFilter* getPoint();

signals:
    void clearAudioParament(int lan_index);

public slots:
    void changeUi();
    void setIndex(int i);
    QVariant getIndex();
    QString getDateFormat(bool isYmd);
    QString getTimeFormat(bool is12);

private:
    int index;
    QQmlContext *content;
    QQmlApplicationEngine engine;
    UsbEventFilter *nativeFilter;
    ConfigureHolder *configureSerialer;
};

#endif // MEDIASCREEN_H
