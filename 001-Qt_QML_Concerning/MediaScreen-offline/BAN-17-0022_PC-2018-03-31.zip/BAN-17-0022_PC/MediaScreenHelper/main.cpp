#include <QGuiApplication>
#include <QMessageBox>
#include <QFont>
#include "usbeventfilter.h"
#include "mediascreen.h"
#include <QFontDatabase>
#include <QCoreApplication>
#include <QDebug>

#if defined Q_OS_WIN32
    #include <windows.h>

bool checkOnly()
{
    HANDLE m_hMutex  =  CreateMutex(NULL, FALSE,  L"MediascreenHelper_2017_06_04" );
    if  (GetLastError()  ==  ERROR_ALREADY_EXISTS)
    {
        CloseHandle(m_hMutex);
        m_hMutex  =  NULL;
        return  false;
    }
    else
    {
        return true;
    }
}
#endif

int main(int argc, char *argv[])
{
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QGuiApplication app(argc, argv);
    QString fontDir = QCoreApplication::applicationDirPath() + "/font/KONE Information_v12.otf";
//    qDebug()<<"fontDir = "<< fontDir;
    QFontDatabase::addApplicationFont(fontDir);
//    qDebug()<< "fontid = "<<fontid;
//    QStringList fontFamily = QFontDatabase::applicationFontFamilies(fontid);
    QFont font("KONE Information_v12");
//    qDebug()<< "fontFamily.at(0) = "<<fontFamily.at(0);
//    font.setFamily(fontFamily.at(0));
    app.setFont(font);

    MediaScreen *mediascreen = new MediaScreen();
    mediascreen->init();
    app.installNativeEventFilter(mediascreen->getPoint());
    int ret = app.exec();
    mediascreen->deleteLater();
    return ret;
}
