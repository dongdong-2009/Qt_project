#ifndef MEDIASCREEN_H
#define MEDIASCREEN_H

#include <QObject>
#include "usbeventfilter.h"
#include "configureholder.h"
#include "ctranslator.h"
#include <QQmlContext>
#include <QQmlApplicationEngine>
#include <QVariant>
#include <QGuiApplication>

class MediaScreen : public QObject
{
    Q_OBJECT
public:
    explicit MediaScreen(QObject *parent = 0);
    void init();
    ~MediaScreen();
    UsbEventFilter* getPoint();
    void setApplication(QGuiApplication* app);
    void getLocalIp();

signals:
    void clearAudioParament(int lan_index);
    void getScrollTextLengthSignal();
    void hasUdiskInsertToComputer(QString uDiskName);

public slots:
    void changeUi();
    void setIndex(int i);
    QVariant getIndex();
    void getScrollTextLength();
    int getSystemLanguage();
    void setPreIndex(int i);
    QVariant getPreIndex();
    QString getIndexIpString(int index);
    QVariant getModel(int index);
    QString getSplitTime(int index);
    QString getSplitDate(int index);
    QString getDateFormat(bool isYmd);
    QString getTimeFormat(bool is12);
    void setUdiskIsInsertFlag(bool flag, QString udiskIndex);
    void sendUdiskInformation();

private:
    int index;
    int preIndex;
    QQmlContext *content;
    QQmlApplicationEngine* engine;
    UsbEventFilter *nativeFilter;
    ConfigureHolder *configureSerialer;
    QString ipString;
    bool isInsertUdiskFlag;
    QString udiskIndexStr;
    QGuiApplication* mApp;
};

#endif // MEDIASCREEN_H
