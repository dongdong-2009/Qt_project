<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>ApnInformation</name>
    <message>
        <location filename="ApnInformation.qml" line="25"/>
        <location filename="ApnInformation.qml" line="218"/>
        <source>国家</source>
        <translation>Country</translation>
    </message>
    <message>
        <location filename="ApnInformation.qml" line="55"/>
        <location filename="ApnInformation.qml" line="219"/>
        <source>运营商</source>
        <translation>NetWork</translation>
    </message>
    <message>
        <location filename="ApnInformation.qml" line="71"/>
        <location filename="ApnInformation.qml" line="99"/>
        <location filename="ApnInformation.qml" line="124"/>
        <location filename="ApnInformation.qml" line="149"/>
        <location filename="ApnInformation.qml" line="175"/>
        <location filename="ApnInformation.qml" line="200"/>
        <location filename="ApnInformation.qml" line="223"/>
        <location filename="ApnInformation.qml" line="224"/>
        <location filename="ApnInformation.qml" line="225"/>
        <location filename="ApnInformation.qml" line="226"/>
        <location filename="ApnInformation.qml" line="227"/>
        <location filename="ApnInformation.qml" line="228"/>
        <source>编辑...</source>
        <translation>Edit...</translation>
    </message>
    <message>
        <location filename="ApnInformation.qml" line="91"/>
        <location filename="ApnInformation.qml" line="220"/>
        <source>接入点</source>
        <translation>APN</translation>
    </message>
    <message>
        <location filename="ApnInformation.qml" line="117"/>
        <source>mcc</source>
        <translation>mcc</translation>
    </message>
    <message>
        <location filename="ApnInformation.qml" line="142"/>
        <source>mnc</source>
        <translation>mnc</translation>
    </message>
    <message>
        <location filename="ApnInformation.qml" line="167"/>
        <location filename="ApnInformation.qml" line="221"/>
        <source>用户名</source>
        <translation>UserName</translation>
    </message>
    <message>
        <location filename="ApnInformation.qml" line="193"/>
        <location filename="ApnInformation.qml" line="222"/>
        <source>密码</source>
        <translation>Password</translation>
    </message>
</context>
<context>
    <name>Area1</name>
    <message>
        <source>亮度&amp;音量</source>
        <translation type="vanished">Screen settings</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="35"/>
        <location filename="Area1.qml" line="346"/>
        <source>屏幕设定</source>
        <translation>Screen settings</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="49"/>
        <location filename="Area1.qml" line="347"/>
        <source>亮度</source>
        <translation>Brightness</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="54"/>
        <location filename="Area1.qml" line="348"/>
        <source>音量</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="165"/>
        <location filename="Area1.qml" line="349"/>
        <source>音频</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="179"/>
        <location filename="Area1.qml" line="350"/>
        <source>开</source>
        <translation>on</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="189"/>
        <location filename="Area1.qml" line="351"/>
        <source>关</source>
        <translation>off</translation>
    </message>
    <message>
        <source>滚动文字</source>
        <translation type="vanished">Scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="199"/>
        <location filename="Area1.qml" line="353"/>
        <source>设置滚动文字</source>
        <translation>Set scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="231"/>
        <location filename="Area1.qml" line="363"/>
        <source>隐藏滚动文字</source>
        <translation>Hide scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="264"/>
        <location filename="Area1.qml" line="354"/>
        <source>设置标题</source>
        <translation>Set title</translation>
    </message>
    <message>
        <source>显示滚动文字</source>
        <translation type="vanished">Show scrolling text</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="212"/>
        <location filename="Area1.qml" line="373"/>
        <source>请输入字幕文字</source>
        <translation>Please enter text here.At least 2 characters.</translation>
    </message>
    <message>
        <source>标题</source>
        <translation type="vanished">Title</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="296"/>
        <location filename="Area1.qml" line="372"/>
        <source>隐藏标题</source>
        <translation>Hide title</translation>
    </message>
    <message>
        <source>显示标题</source>
        <translation type="vanished">Show title</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="276"/>
        <location filename="Area1.qml" line="375"/>
        <location filename="Area1.qml" line="392"/>
        <source>请输入标题文字</source>
        <translation>Please enter text here. 2 to 16 characters.</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="317"/>
        <location filename="Area1.qml" line="376"/>
        <source>系统时间设置</source>
        <translation>SystemTimeSetting</translation>
    </message>
    <message>
        <location filename="Area1.qml" line="388"/>
        <source>请输入滚动字幕文字</source>
        <translation>Please enter text here. Mini 2 characters.</translation>
    </message>
</context>
<context>
    <name>Area2</name>
    <message>
        <source>显示时间和日期</source>
        <translation type="vanished">Show time and date</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="55"/>
        <location filename="Area2.qml" line="675"/>
        <source>时间格式</source>
        <translation>Time format</translation>
    </message>
    <message>
        <source>音频</source>
        <oldsource>音频关</oldsource>
        <translation type="vanished">Audio</translation>
    </message>
    <message>
        <source>音频开</source>
        <translation type="vanished">Audio On</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="676"/>
        <source>12上午下午  </source>
        <translation>12 AM/PM</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="96"/>
        <location filename="Area2.qml" line="677"/>
        <source>24小时</source>
        <translation>24 hours</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="112"/>
        <location filename="Area2.qml" line="681"/>
        <source>隐藏时间和日期</source>
        <translation>Hide time and date</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="60"/>
        <location filename="Area2.qml" line="678"/>
        <source>日期格式</source>
        <translation>Date format</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="40"/>
        <location filename="Area2.qml" line="674"/>
        <source>时间和日期</source>
        <translation>Time and date</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="70"/>
        <source>12上午下午</source>
        <translation>12AM/PM</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="81"/>
        <source>yyyy:MM:dd</source>
        <oldsource>yyyy:mm:dd</oldsource>
        <translation>yyyy:MM:dd</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="100"/>
        <source>dd:MM:yyyy</source>
        <oldsource>dd:mm:yyyy</oldsource>
        <translation>dd:MM:yyyy</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="394"/>
        <location filename="Area2.qml" line="422"/>
        <location filename="Area2.qml" line="447"/>
        <location filename="Area2.qml" line="472"/>
        <location filename="Area2.qml" line="498"/>
        <location filename="Area2.qml" line="523"/>
        <location filename="Area2.qml" line="694"/>
        <location filename="Area2.qml" line="695"/>
        <location filename="Area2.qml" line="696"/>
        <location filename="Area2.qml" line="697"/>
        <location filename="Area2.qml" line="698"/>
        <location filename="Area2.qml" line="699"/>
        <source>编辑...</source>
        <translation>Edit...</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="606"/>
        <location filename="Area2.qml" line="607"/>
        <source>255</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area2.qml" line="608"/>
        <location filename="Area2.qml" line="609"/>
        <location filename="Area2.qml" line="631"/>
        <location filename="Area2.qml" line="652"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area2.qml" line="628"/>
        <location filename="Area2.qml" line="650"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area2.qml" line="629"/>
        <location filename="Area2.qml" line="651"/>
        <source>200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area2.qml" line="630"/>
        <source>254</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area2.qml" line="653"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area2.qml" line="682"/>
        <source>国家</source>
        <translation>Country</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="683"/>
        <source>运营商</source>
        <translation>NetWork</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="684"/>
        <source>接入点</source>
        <translation>APN</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="685"/>
        <source>用户名</source>
        <translation>UserName</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="686"/>
        <source>密码</source>
        <translation>Password</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="687"/>
        <source>Ip设定</source>
        <translation>IpSetting</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="688"/>
        <source>自动</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="689"/>
        <source>手动</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="690"/>
        <source>IP地址:</source>
        <translation>IPAddress:</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="691"/>
        <source>子网掩码:</source>
        <translation>SubnetMask:</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="692"/>
        <source>默认网关:</source>
        <translation>DefaultRoute:</translation>
    </message>
    <message>
        <location filename="Area2.qml" line="693"/>
        <source>首选DNS服务器:</source>
        <translation>DNSService:</translation>
    </message>
    <message>
        <source>开</source>
        <translation type="vanished">on</translation>
    </message>
    <message>
        <source>关</source>
        <translation type="vanished">off</translation>
    </message>
    <message>
        <source>mm:dd:yyyy</source>
        <translation type="vanished">dd:mm:yyyy</translation>
    </message>
    <message>
        <source>屏保</source>
        <translation type="vanished">Screensaver settings</translation>
    </message>
    <message>
        <source>一阶段周期(S)</source>
        <translation type="vanished">One stage cycle(S)</translation>
    </message>
    <message>
        <source>亮度</source>
        <translation type="vanished">Brightness</translation>
    </message>
    <message>
        <source>二阶段周期(S)</source>
        <translation type="vanished">Two stage cycle(S)</translation>
    </message>
</context>
<context>
    <name>Area3</name>
    <message>
        <location filename="Area3.qml" line="27"/>
        <location filename="Area3.qml" line="575"/>
        <source>多媒体更新</source>
        <translation>Screen lay-out</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="48"/>
        <location filename="Area3.qml" line="576"/>
        <source>正常显示</source>
        <translation>With elevator information</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="60"/>
        <location filename="Area3.qml" line="577"/>
        <source>全屏显示</source>
        <translation>Fullscreen media</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="90"/>
        <location filename="Area3.qml" line="590"/>
        <source>添加多媒体</source>
        <translation>Add media content</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="103"/>
        <location filename="Area3.qml" line="578"/>
        <source>视频</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="126"/>
        <location filename="Area3.qml" line="579"/>
        <source>音频</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="148"/>
        <location filename="Area3.qml" line="580"/>
        <source>图片</source>
        <translation>Picture</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="198"/>
        <location filename="Area3.qml" line="581"/>
        <source>选择视频</source>
        <translation>Select video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="249"/>
        <location filename="Area3.qml" line="583"/>
        <source>选择音频</source>
        <translation>Select Audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="283"/>
        <location filename="Area3.qml" line="582"/>
        <source>选择图片</source>
        <translation>Select Picture</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="325"/>
        <location filename="Area3.qml" line="589"/>
        <source>间隔</source>
        <translation>interval</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="390"/>
        <location filename="Area3.qml" line="584"/>
        <source>添加</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="396"/>
        <location filename="Area3.qml" line="585"/>
        <source>删除</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="401"/>
        <location filename="Area3.qml" line="586"/>
        <source>清空</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="415"/>
        <location filename="Area3.qml" line="591"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="494"/>
        <location filename="Area3.qml" line="587"/>
        <source>请选择一个视频文件</source>
        <translation>Please select pictures</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="505"/>
        <source>请选择一个音频文件</source>
        <translation>Please select audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="531"/>
        <location filename="Area3.qml" line="588"/>
        <source>请选取图片</source>
        <translation>Please select pictures</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="554"/>
        <source>请选择一个视频</source>
        <translation>Please select a video</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="560"/>
        <source>请选择一个音频</source>
        <translation>Please select audio</translation>
    </message>
    <message>
        <location filename="Area3.qml" line="566"/>
        <source>请选择图片</source>
        <translation>Please select pictures</translation>
    </message>
</context>
<context>
    <name>Area4</name>
    <message>
        <location filename="Area4.qml" line="21"/>
        <location filename="Area4.qml" line="202"/>
        <source>语言切换</source>
        <translation>Language selection</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="38"/>
        <source>中文</source>
        <translation>Chinese</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="61"/>
        <source>繁體</source>
        <oldsource>繁体</oldsource>
        <translation type="unfinished">Traditional</translation>
    </message>
    <message>
        <location filename="Area4.qml" line="85"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Area4.qml" line="106"/>
        <source>русский язык</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>英语</source>
        <translation type="vanished">English</translation>
    </message>
    <message>
        <source>俄语</source>
        <translation type="vanished">Russian</translation>
    </message>
</context>
<context>
    <name>Area5</name>
    <message>
        <location filename="Area5.qml" line="15"/>
        <location filename="Area5.qml" line="278"/>
        <source>升级盘制作</source>
        <translation>Upgrade content on USB</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="92"/>
        <location filename="Area5.qml" line="279"/>
        <source>重置为默认配置</source>
        <translation>Reset default configuration</translation>
    </message>
    <message>
        <source>界面预览</source>
        <translation type="vanished">Screen Preview</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="33"/>
        <location filename="Area5.qml" line="280"/>
        <source>制作升级盘</source>
        <translation>Select device:</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="53"/>
        <location filename="Area5.qml" line="281"/>
        <source>制作</source>
        <translation>UPLOAD</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="vanished">Formatting U disk.....</translation>
    </message>
    <message>
        <location filename="Area5.qml" line="282"/>
        <source>拷贝文件...</source>
        <translation>Copy file...</translation>
    </message>
    <message>
        <source>正在生成配置参数</source>
        <translation type="vanished">Generating configuration parameters...</translation>
    </message>
    <message>
        <source>升级盘制作成功</source>
        <translation type="vanished">Upgrade disk production success</translation>
    </message>
</context>
<context>
    <name>Horizontal_ImageOrVideo</name>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="39"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="142"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="66"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="143"/>
        <source>横屏显示</source>
        <translation>Horizontal Show</translation>
    </message>
    <message>
        <location filename="Horizontal_ImageOrVideo.qml" line="87"/>
        <location filename="Horizontal_ImageOrVideo.qml" line="144"/>
        <source>竖屏显示</source>
        <translation>Vertical Show</translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="39"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="66"/>
        <source>кросс экраном</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Horizontal_ImageOrVideo.qml" line="88"/>
        <source>вертикальный экран</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MakeDisk</name>
    <message>
        <source>重置为默认配置</source>
        <translation type="obsolete">Reset default configuration</translation>
    </message>
    <message>
        <source>制作升级盘</source>
        <translation type="obsolete">Make upgrade disk</translation>
    </message>
    <message>
        <source>制作</source>
        <translation type="obsolete">Making</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="obsolete">Formatting U disk.....</translation>
    </message>
    <message>
        <source>拷贝文件...</source>
        <translation type="obsolete">Copy file...</translation>
    </message>
    <message>
        <source>正在生成配置参数</source>
        <translation type="obsolete">Generating configuration parameters...</translation>
    </message>
    <message>
        <source>升级盘制作成功</source>
        <translation type="obsolete">Upgrade disk production success</translation>
    </message>
</context>
<context>
    <name>ModifyCheckBox</name>
    <message>
        <source>重置为默认配置</source>
        <translation type="obsolete">Reset default configuration</translation>
    </message>
</context>
<context>
    <name>MultiMedia</name>
    <message>
        <source>视频</source>
        <translation type="obsolete">Video</translation>
    </message>
    <message>
        <source>图片</source>
        <translation type="obsolete">Picture</translation>
    </message>
    <message>
        <source>正常显示</source>
        <translation type="obsolete">Normal display</translation>
    </message>
    <message>
        <source>全屏显示</source>
        <translation type="obsolete">Fullscreen display</translation>
    </message>
    <message>
        <source>选择视频</source>
        <translation type="obsolete">Select video</translation>
    </message>
    <message>
        <source>选择图片</source>
        <translation type="obsolete">Select Picture</translation>
    </message>
    <message>
        <source>添加</source>
        <translation type="obsolete">Add</translation>
    </message>
    <message>
        <source>删除</source>
        <translation type="obsolete">Delete</translation>
    </message>
    <message>
        <source>清空</source>
        <translation type="obsolete">Clear</translation>
    </message>
    <message>
        <source>请选择一个视频文件</source>
        <translation type="obsolete">Please select pictures</translation>
    </message>
    <message>
        <source>请选取图片</source>
        <translation type="obsolete">Please select pictures</translation>
    </message>
</context>
<context>
    <name>Parameter</name>
    <message>
        <source>亮度&amp;音量</source>
        <translation type="obsolete">Brightness &amp; volume</translation>
    </message>
    <message>
        <source>滚动文字</source>
        <translation type="obsolete">Scrolling text</translation>
    </message>
    <message>
        <source>标题</source>
        <translation type="obsolete">Title</translation>
    </message>
    <message>
        <source>屏保</source>
        <translation type="obsolete">Screensaver</translation>
    </message>
    <message>
        <source>亮度</source>
        <translation type="obsolete">Brightness</translation>
    </message>
    <message>
        <source>音量</source>
        <translation type="obsolete">Volume</translation>
    </message>
    <message>
        <source>请输入字幕文字</source>
        <translation type="obsolete">Please enter a caption text</translation>
    </message>
    <message>
        <source>时间格式</source>
        <translation type="obsolete">Time format</translation>
    </message>
    <message>
        <source>日期格式</source>
        <translation type="obsolete">Date format</translation>
    </message>
    <message>
        <source>显示标题</source>
        <translation type="obsolete">Show title</translation>
    </message>
    <message>
        <source>隐藏标题</source>
        <translation type="obsolete">Hide title</translation>
    </message>
    <message>
        <source>请输入标题文字</source>
        <translation type="obsolete">Please enter a title text</translation>
    </message>
</context>
<context>
    <name>RussianArea1</name>
    <message>
        <location filename="russian/RussianArea1.qml" line="55"/>
        <source>Яркость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="61"/>
        <source>Громкость</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="201"/>
        <source>переходящий текст настройки</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="229"/>
        <source>Скрытие прокрутки текста</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="212"/>
        <source>Введите субтитра</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="261"/>
        <source>установить заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="293"/>
        <source>Скрытие заголовка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="273"/>
        <location filename="russian/RussianArea1.qml" line="349"/>
        <source>Введите заголовок</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="43"/>
        <source>экран настройки</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="169"/>
        <source>аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="180"/>
        <location filename="russian/RussianArea1.qml" line="190"/>
        <source>аудио гуань</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="317"/>
        <source>Настройки системы времени</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea1.qml" line="344"/>
        <source>Введите прокрутку субтитра</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea2</name>
    <message>
        <location filename="russian/RussianArea2.qml" line="107"/>
        <source>Скрыть времни и даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="38"/>
        <source>время и дата</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="50"/>
        <source>Формат времени</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="56"/>
        <source>Формат даты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="67"/>
        <source>12 Часов</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="133"/>
        <source>country</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="163"/>
        <source>network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="179"/>
        <location filename="russian/RussianArea2.qml" line="207"/>
        <location filename="russian/RussianArea2.qml" line="232"/>
        <location filename="russian/RussianArea2.qml" line="257"/>
        <location filename="russian/RussianArea2.qml" line="283"/>
        <location filename="russian/RussianArea2.qml" line="308"/>
        <source>редактор...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="199"/>
        <source>APN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="275"/>
        <source>UserName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="301"/>
        <source>password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="329"/>
        <source>IP настройки</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="340"/>
        <source>автоматически</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="350"/>
        <source>вручную</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="360"/>
        <source> IP-адрес:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="382"/>
        <source>Маска подсети:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="391"/>
        <location filename="russian/RussianArea2.qml" line="392"/>
        <source>255</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="393"/>
        <location filename="russian/RussianArea2.qml" line="394"/>
        <location filename="russian/RussianArea2.qml" line="416"/>
        <location filename="russian/RussianArea2.qml" line="437"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="404"/>
        <source>Шлюз по умолчанию:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="413"/>
        <location filename="russian/RussianArea2.qml" line="435"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="414"/>
        <location filename="russian/RussianArea2.qml" line="436"/>
        <source>200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="415"/>
        <source>254</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="426"/>
        <source>DNS - сервис:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="438"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>yyyy:MM:dd</source>
        <oldsource>yyyy:mm:dd</oldsource>
        <translation type="obsolete">yyyy:mm:dd</translation>
    </message>
    <message>
        <location filename="russian/RussianArea2.qml" line="93"/>
        <source>24 Часов</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>dd:MM:yyyy</source>
        <oldsource>dd:mm:yyyy</oldsource>
        <translation type="obsolete">dd:mm:yyyy</translation>
    </message>
    <message>
        <source>mm:dd:yyyy</source>
        <translation type="obsolete">mm:dd:yyyy</translation>
    </message>
</context>
<context>
    <name>RussianArea3</name>
    <message>
        <location filename="russian/RussianArea3.qml" line="26"/>
        <source>Обновление мультимедиа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="48"/>
        <source>Нормальная индикация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="61"/>
        <source>Полноэкранная индикация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="84"/>
        <source>Добавить мультимедиа</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="98"/>
        <source>Видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="121"/>
        <source>аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="144"/>
        <source>Картина</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="195"/>
        <source>Выбор видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="246"/>
        <location filename="russian/RussianArea3.qml" line="512"/>
        <location filename="russian/RussianArea3.qml" line="563"/>
        <source>выбрать аудио</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="281"/>
        <source>Выбор картины</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="323"/>
        <source>интервал</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="395"/>
        <source>Добавить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="401"/>
        <source>Удалить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="407"/>
        <source>Очистить</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="421"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="500"/>
        <location filename="russian/RussianArea3.qml" line="556"/>
        <source>Выберите видео</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="539"/>
        <location filename="russian/RussianArea3.qml" line="569"/>
        <source>Выберите картину</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="578"/>
        <source>多媒体更新</source>
        <translation type="unfinished">Multimedia update</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="579"/>
        <source>正常显示</source>
        <translation type="unfinished">Normal display</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="580"/>
        <source>全屏显示</source>
        <translation type="unfinished">Fullscreen display</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="581"/>
        <source>视频</source>
        <translation type="unfinished">Video</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="582"/>
        <source>音频</source>
        <translation type="unfinished">Audio</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="583"/>
        <source>图片</source>
        <translation type="unfinished">Picture</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="584"/>
        <source>选择视频</source>
        <translation type="unfinished">Select video</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="585"/>
        <source>选择图片</source>
        <translation type="unfinished">Select Picture</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="586"/>
        <source>选择音频</source>
        <translation type="unfinished">Select Audio</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="587"/>
        <source>添加</source>
        <translation type="unfinished">Add</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="588"/>
        <source>删除</source>
        <translation type="unfinished">Delete</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="589"/>
        <source>清空</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="590"/>
        <source>请选择一个视频文件</source>
        <translation type="unfinished">Please select pictures</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="591"/>
        <source>请选取图片</source>
        <translation type="unfinished">Please select pictures</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="592"/>
        <source>间隔</source>
        <translation type="unfinished">interval</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="593"/>
        <source>添加多媒体</source>
        <translation type="unfinished">Add media content</translation>
    </message>
    <message>
        <location filename="russian/RussianArea3.qml" line="594"/>
        <source>界面预览</source>
        <translation type="unfinished">Screen Preview</translation>
    </message>
</context>
<context>
    <name>RussianArea4</name>
    <message>
        <location filename="russian/RussianArea4.qml" line="22"/>
        <source>Переключатель языка</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="39"/>
        <source>中文</source>
        <translation type="unfinished">Chinese</translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="61"/>
        <source>繁體</source>
        <translation type="unfinished">Traditional</translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="84"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea4.qml" line="105"/>
        <source>Русский язык</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianArea5</name>
    <message>
        <location filename="russian/RussianArea5.qml" line="16"/>
        <source>Поделка обновления диска </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="95"/>
        <source>Вновь установления настройки по умолчанию</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="38"/>
        <source>Поделка обновления диска</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianArea5.qml" line="58"/>
        <source>Поделка</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RussianMain</name>
    <message>
        <location filename="russian/RussianMain.qml" line="34"/>
        <source>MediaScreen Content management</source>
        <oldsource>MediaScreenHelper</oldsource>
        <translation type="unfinished">MediaScreenHelper</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="obsolete">  V1.7.0</translation>
    </message>
    <message>
        <source>  V1.2.0</source>
        <translation type="obsolete">  V1.2.0</translation>
    </message>
    <message>
        <source>  V2.0.0</source>
        <translation type="obsolete">  V2.0.0</translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="34"/>
        <source>  V2.2.0</source>
        <translation type="unfinished">  V2.2.0</translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="48"/>
        <source>Настройка параметров</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="175"/>
        <source>Включите этот параметр переключателя, на экране будет восстановлена настройка параметров по умолчанию. Мультимедиа, прокрутка субтитров, заголовок, времени и даты, параметры конфигурации системы буду
т восстановлены по умолчанию.</source>
        <oldsource>Включите этот параметр переключателя, на экране будет восстановлена настройка параметров по умолчанию. Мультимедиа, прокрутка субтитров, заголовок, времени и даты, параметры конфигурации системы буду
т восстановлены по умолчанию.</oldsource>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="188"/>
        <location filename="russian/RussianMain.qml" line="232"/>
        <location filename="russian/RussianMain.qml" line="384"/>
        <source>Уточнение</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="196"/>
        <location filename="russian/RussianMain.qml" line="395"/>
        <source>Отмена</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="290"/>
        <source>Нажмите, чтобы закончить поделку</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="312"/>
        <source>Копирование файла...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="372"/>
        <source>Нажмите, чтобы подтвердить.Размещение страницы будет перезагружен.Необходимо перезагрузить USB!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="422"/>
        <source>Создание параметров конфигурации</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="425"/>
        <source>Успех в поделке обновлении диска</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="441"/>
        <source>проверить диска...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/RussianMain.qml" line="452"/>
        <source>拷贝文件...</source>
        <translation type="unfinished">Copy file...</translation>
    </message>
</context>
<context>
    <name>Self_TextField</name>
    <message>
        <location filename="Self_TextField.qml" line="29"/>
        <location filename="Self_TextField.qml" line="285"/>
        <location filename="russian/Self_TextField.qml" line="285"/>
        <source>年</source>
        <translation>Y</translation>
    </message>
    <message>
        <location filename="Self_TextField.qml" line="40"/>
        <location filename="Self_TextField.qml" line="286"/>
        <location filename="russian/Self_TextField.qml" line="286"/>
        <source>月</source>
        <translation>M</translation>
    </message>
    <message>
        <location filename="Self_TextField.qml" line="51"/>
        <location filename="Self_TextField.qml" line="287"/>
        <location filename="russian/Self_TextField.qml" line="287"/>
        <source>日</source>
        <translation>D</translation>
    </message>
    <message>
        <location filename="Self_TextField.qml" line="62"/>
        <location filename="Self_TextField.qml" line="288"/>
        <location filename="russian/Self_TextField.qml" line="288"/>
        <source>时</source>
        <translation>H</translation>
    </message>
    <message>
        <location filename="Self_TextField.qml" line="73"/>
        <location filename="Self_TextField.qml" line="289"/>
        <location filename="russian/Self_TextField.qml" line="289"/>
        <source>分</source>
        <translation>m</translation>
    </message>
    <message>
        <location filename="Self_TextField.qml" line="84"/>
        <location filename="Self_TextField.qml" line="290"/>
        <location filename="russian/Self_TextField.qml" line="290"/>
        <source>秒</source>
        <translation>s</translation>
    </message>
    <message>
        <location filename="russian/Self_TextField.qml" line="29"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Self_TextField.qml" line="40"/>
        <source>M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Self_TextField.qml" line="51"/>
        <source>D</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Self_TextField.qml" line="62"/>
        <source>h</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Self_TextField.qml" line="73"/>
        <source>m</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Self_TextField.qml" line="84"/>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Self_TextField_column</name>
    <message>
        <location filename="Self_TextField_column.qml" line="23"/>
        <source>年</source>
        <translation type="unfinished">Y</translation>
    </message>
    <message>
        <location filename="Self_TextField_column.qml" line="64"/>
        <source>月</source>
        <translation type="unfinished">M</translation>
    </message>
    <message>
        <location filename="Self_TextField_column.qml" line="103"/>
        <source>日</source>
        <translation type="unfinished">D</translation>
    </message>
    <message>
        <location filename="Self_TextField_column.qml" line="142"/>
        <source>时</source>
        <translation type="unfinished">H</translation>
    </message>
    <message>
        <location filename="Self_TextField_column.qml" line="181"/>
        <source>分</source>
        <translation type="unfinished">m</translation>
    </message>
    <message>
        <location filename="Self_TextField_column.qml" line="220"/>
        <source>秒</source>
        <translation type="unfinished">s</translation>
    </message>
</context>
<context>
    <name>TestArea1</name>
    <message>
        <location filename="TestArea1.qml" line="30"/>
        <location filename="TestArea1.qml" line="304"/>
        <source>屏幕设定</source>
        <translation>Screen settings</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="38"/>
        <location filename="TestArea1.qml" line="305"/>
        <source>亮度</source>
        <translation>Brightness</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="85"/>
        <location filename="TestArea1.qml" line="306"/>
        <source>音量</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="162"/>
        <location filename="TestArea1.qml" line="307"/>
        <source>音频</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="172"/>
        <location filename="TestArea1.qml" line="308"/>
        <source>开</source>
        <translation>on</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="185"/>
        <location filename="TestArea1.qml" line="309"/>
        <source>关</source>
        <translation>off</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="192"/>
        <location filename="TestArea1.qml" line="311"/>
        <source>设置滚动文字</source>
        <translation>Set scrolling text</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="201"/>
        <location filename="TestArea1.qml" line="331"/>
        <source>请输入字幕文字</source>
        <translation>Please enter text here.At least 2 characters.</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="218"/>
        <location filename="TestArea1.qml" line="321"/>
        <source>隐藏滚动文字</source>
        <translation>Hide scrolling text</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="230"/>
        <location filename="TestArea1.qml" line="312"/>
        <source>设置标题</source>
        <translation>Set title</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="239"/>
        <location filename="TestArea1.qml" line="333"/>
        <location filename="TestArea1.qml" line="351"/>
        <source>请输入标题文字</source>
        <translation>Please enter text here. 2 to 16 characters.</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="256"/>
        <location filename="TestArea1.qml" line="330"/>
        <source>隐藏标题</source>
        <translation>Hide title</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="268"/>
        <location filename="TestArea1.qml" line="334"/>
        <source>系统时间设置</source>
        <translation>SystemTimeSetting</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="290"/>
        <location filename="TestArea1.qml" line="336"/>
        <source>隐藏系统时间</source>
        <translation>Hide SystemTime</translation>
    </message>
    <message>
        <location filename="TestArea1.qml" line="347"/>
        <source>请输入滚动字幕文字</source>
        <translation>Please enter text here. Mini 2 characters.</translation>
    </message>
</context>
<context>
    <name>TestArea2</name>
    <message>
        <location filename="TestArea2.qml" line="33"/>
        <location filename="TestArea2.qml" line="241"/>
        <source>时间和日期</source>
        <translation>Time and date</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="41"/>
        <location filename="TestArea2.qml" line="242"/>
        <source>时间格式</source>
        <translation>Time format</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="48"/>
        <location filename="TestArea2.qml" line="245"/>
        <source>日期格式</source>
        <translation>Date format</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="60"/>
        <source>12上午下午</source>
        <translation>12AM/PM</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="85"/>
        <source>yyyy:MM:dd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="72"/>
        <location filename="TestArea2.qml" line="244"/>
        <source>24小时</source>
        <translation>24 hours</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="94"/>
        <source>dd:MM:yyyy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="101"/>
        <location filename="TestArea2.qml" line="246"/>
        <source>隐藏时间和日期</source>
        <translation>Hide time and date</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="155"/>
        <location filename="TestArea2.qml" line="252"/>
        <source>IP地址:</source>
        <translation>IPAddress:</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="137"/>
        <location filename="TestArea2.qml" line="250"/>
        <source>自动</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="118"/>
        <location filename="TestArea2.qml" line="248"/>
        <source>隐藏Apn</source>
        <translation>Hide Apn</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="145"/>
        <location filename="TestArea2.qml" line="251"/>
        <source>手动</source>
        <translation>Manual</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="176"/>
        <location filename="TestArea2.qml" line="253"/>
        <source>子网掩码:</source>
        <translation>SubnetMask:</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="184"/>
        <location filename="TestArea2.qml" line="185"/>
        <source>255</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="186"/>
        <location filename="TestArea2.qml" line="187"/>
        <location filename="TestArea2.qml" line="208"/>
        <location filename="TestArea2.qml" line="228"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="197"/>
        <location filename="TestArea2.qml" line="254"/>
        <source>默认网关:</source>
        <translation>DefaultRoute:</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="205"/>
        <location filename="TestArea2.qml" line="226"/>
        <source>10</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="206"/>
        <location filename="TestArea2.qml" line="227"/>
        <source>200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="207"/>
        <source>254</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="218"/>
        <location filename="TestArea2.qml" line="255"/>
        <source>首选DNS服务器:</source>
        <oldsource>首选DNS服务:</oldsource>
        <translation>DNSService:</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="127"/>
        <location filename="TestArea2.qml" line="249"/>
        <source>Ip设定</source>
        <translation>IpSetting</translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="229"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea2.qml" line="243"/>
        <source>12上午下午  </source>
        <translation type="unfinished">12 AM/PM</translation>
    </message>
    <message>
        <source>国家</source>
        <translation type="vanished">Country</translation>
    </message>
    <message>
        <source>运营商</source>
        <translation type="vanished">NetWork</translation>
    </message>
    <message>
        <source>接入点</source>
        <translation type="vanished">APN</translation>
    </message>
    <message>
        <source>用户名</source>
        <translation type="vanished">UserName</translation>
    </message>
    <message>
        <source>密码</source>
        <translation type="vanished">Password</translation>
    </message>
</context>
<context>
    <name>TestArea3</name>
    <message>
        <location filename="TestArea3.qml" line="25"/>
        <location filename="TestArea3.qml" line="533"/>
        <source>多媒体更新</source>
        <translation>Screen lay-out</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="36"/>
        <location filename="TestArea3.qml" line="534"/>
        <source>正常显示</source>
        <translation>With elevator information</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="44"/>
        <location filename="TestArea3.qml" line="535"/>
        <source>全屏显示</source>
        <translation>Fullscreen media</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="68"/>
        <location filename="TestArea3.qml" line="548"/>
        <source>添加多媒体</source>
        <translation>Add media content</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="80"/>
        <location filename="TestArea3.qml" line="536"/>
        <source>视频</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="95"/>
        <location filename="TestArea3.qml" line="537"/>
        <source>音频</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="110"/>
        <location filename="TestArea3.qml" line="538"/>
        <source>图片</source>
        <translation>Picture</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="146"/>
        <location filename="TestArea3.qml" line="539"/>
        <source>选择视频</source>
        <translation>Select video</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="198"/>
        <location filename="TestArea3.qml" line="541"/>
        <source>选择音频</source>
        <translation>Select Audio</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="231"/>
        <location filename="TestArea3.qml" line="540"/>
        <source>选择图片</source>
        <translation>Select Picture</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="274"/>
        <location filename="TestArea3.qml" line="547"/>
        <source>间隔</source>
        <translation>interval</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="338"/>
        <location filename="TestArea3.qml" line="542"/>
        <source>添加</source>
        <translation>Add</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="347"/>
        <location filename="TestArea3.qml" line="543"/>
        <source>删除</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="352"/>
        <location filename="TestArea3.qml" line="544"/>
        <source>清空</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="368"/>
        <location filename="TestArea3.qml" line="549"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="452"/>
        <location filename="TestArea3.qml" line="545"/>
        <source>请选择一个视频文件</source>
        <translation>Please select pictures</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="463"/>
        <source>请选择一个音频文件</source>
        <translation>Please select audio</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="489"/>
        <location filename="TestArea3.qml" line="546"/>
        <source>请选取图片</source>
        <translation>Please select pictures</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="512"/>
        <source>请选择一个视频</source>
        <translation>Please select a video</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="518"/>
        <source>请选择一个音频</source>
        <translation>Please select audio</translation>
    </message>
    <message>
        <location filename="TestArea3.qml" line="524"/>
        <source>请选择图片</source>
        <translation>Please select pictures</translation>
    </message>
</context>
<context>
    <name>TestArea4</name>
    <message>
        <location filename="TestArea4.qml" line="21"/>
        <location filename="TestArea4.qml" line="165"/>
        <source>语言切换</source>
        <translation>Language selection</translation>
    </message>
    <message>
        <location filename="TestArea4.qml" line="31"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea4.qml" line="46"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea4.qml" line="61"/>
        <source>繁體</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="TestArea4.qml" line="78"/>
        <source>русский язык</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TestArea5</name>
    <message>
        <location filename="TestArea5.qml" line="21"/>
        <location filename="TestArea5.qml" line="244"/>
        <source>制作升级盘</source>
        <translation>Select device:</translation>
    </message>
    <message>
        <location filename="TestArea5.qml" line="40"/>
        <location filename="TestArea5.qml" line="243"/>
        <source>重置为默认配置</source>
        <translation>Reset default configuration</translation>
    </message>
    <message>
        <location filename="TestArea5.qml" line="64"/>
        <location filename="TestArea5.qml" line="245"/>
        <source>制作</source>
        <translation>UPLOAD</translation>
    </message>
    <message>
        <location filename="TestArea5.qml" line="12"/>
        <location filename="TestArea5.qml" line="242"/>
        <source>升级盘制作</source>
        <translation>Upgrade content on USB</translation>
    </message>
    <message>
        <location filename="TestArea5.qml" line="246"/>
        <source>拷贝文件...</source>
        <translation>Copy file...</translation>
    </message>
</context>
<context>
    <name>Vertical_ImageOrVideo</name>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="38"/>
        <location filename="Vertical_ImageOrVideo.qml" line="131"/>
        <source>界面预览</source>
        <translation>Screen Preview</translation>
    </message>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="63"/>
        <location filename="Vertical_ImageOrVideo.qml" line="132"/>
        <source>横屏显示</source>
        <translation>Horizontal Show</translation>
    </message>
    <message>
        <location filename="Vertical_ImageOrVideo.qml" line="91"/>
        <location filename="Vertical_ImageOrVideo.qml" line="133"/>
        <source>竖屏显示</source>
        <translation>Vertical Show</translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="38"/>
        <source>интерфейс просмотр</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="62"/>
        <source>кросс экраном</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="russian/Vertical_ImageOrVideo.qml" line="89"/>
        <source>вертикальный экран</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="35"/>
        <source>MediaScreen Content management</source>
        <oldsource>MediaScreenHelper</oldsource>
        <translation>MediaScreenHelper</translation>
    </message>
    <message>
        <source>  V1.6.0</source>
        <translation type="vanished">  V1.6.0</translation>
    </message>
    <message>
        <source>  V1.7.0</source>
        <translation type="vanished">  V1.7.0</translation>
    </message>
    <message>
        <source>  V1.2.0</source>
        <translation type="vanished">  V1.2.0</translation>
    </message>
    <message>
        <source>  V2.0.0</source>
        <translation type="vanished">  V2.0.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="35"/>
        <source>  V2.2.0</source>
        <translation type="unfinished">  V2.2.0</translation>
    </message>
    <message>
        <location filename="main.qml" line="49"/>
        <location filename="main.qml" line="506"/>
        <source>参数设置</source>
        <translation>Parameter setting</translation>
    </message>
    <message>
        <location filename="main.qml" line="209"/>
        <location filename="main.qml" line="507"/>
        <source>打开此开关选项,屏幕将恢复默认的参数配置.多媒体,滚动字幕,标题,时间和日期,系统配置参数都将恢复为默认.</source>
        <translation>If you confirm this selection, the screen will restore the default settings. All parameters including scrolling text, title, time and date and multimedia will be restored to default settings.</translation>
    </message>
    <message>
        <location filename="main.qml" line="220"/>
        <location filename="main.qml" line="468"/>
        <location filename="main.qml" line="508"/>
        <location filename="main.qml" line="514"/>
        <source>确认</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="main.qml" line="227"/>
        <location filename="main.qml" line="479"/>
        <location filename="main.qml" line="509"/>
        <location filename="main.qml" line="515"/>
        <source>取消</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="main.qml" line="262"/>
        <location filename="main.qml" line="387"/>
        <location filename="main.qml" line="510"/>
        <source>确定</source>
        <translation>Confirm</translation>
    </message>
    <message>
        <location filename="main.qml" line="318"/>
        <location filename="main.qml" line="511"/>
        <source>点击以结束制作</source>
        <translation>Clicked and ended making</translation>
    </message>
    <message>
        <location filename="main.qml" line="341"/>
        <location filename="main.qml" line="512"/>
        <location filename="main.qml" line="552"/>
        <source>拷贝文件...</source>
        <translation>Copy file...</translation>
    </message>
    <message>
        <location filename="main.qml" line="457"/>
        <location filename="main.qml" line="513"/>
        <source>点击确认，将重新加载界面布局，Usb设备需要重新插拔!</source>
        <oldsource>点击确认，将重新加载界面布局，Usb设备需要重新插拔！.</oldsource>
        <translation>Click OK to reload the interface layout, and the Usb device needs to be reinserted!</translation>
    </message>
    <message>
        <location filename="main.qml" line="521"/>
        <source>正在生成配置参数</source>
        <translation>Generating configuration parameters...</translation>
    </message>
    <message>
        <location filename="main.qml" line="523"/>
        <source>升级盘制作成功</source>
        <translation>Upgrade disk production success</translation>
    </message>
    <message>
        <location filename="main.qml" line="539"/>
        <source>正在检查U盘...</source>
        <translation>Checking Udisk...</translation>
    </message>
    <message>
        <source>正在格式化U盘...</source>
        <translation type="vanished">Formatting U disk.....</translation>
    </message>
</context>
</TS>
